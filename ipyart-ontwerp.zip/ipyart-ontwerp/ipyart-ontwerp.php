<?php
/**
 * Plugin Name:       IPY ART Ontwerp
 * Description:       Nieuw ontwerp voor ipyart.com: gedichten, ontwerppatronen, nieuwsbrief (MailerLite) en een previewmodus om het ontwerp eerst als beheerder te bekijken.
 * Version:           0.1.0
 * Requires at least: 6.7
 * Requires PHP:      7.4
 * Author:            IPY ART
 * License:           GPL-2.0-or-later
 * Text Domain:       ipyart-ontwerp
 */

defined( 'ABSPATH' ) || exit;

define( 'IPYART_ONTWERP_VERSION', '0.1.0' );
define( 'IPYART_ONTWERP_DIR', plugin_dir_path( __FILE__ ) );
define( 'IPYART_ONTWERP_URL', plugin_dir_url( __FILE__ ) );

require_once IPYART_ONTWERP_DIR . 'inc/instellingen.php';
require_once IPYART_ONTWERP_DIR . 'inc/modus.php';
require_once IPYART_ONTWERP_DIR . 'inc/stijl.php';
require_once IPYART_ONTWERP_DIR . 'inc/gedichten.php';
require_once IPYART_ONTWERP_DIR . 'inc/patronen.php';
require_once IPYART_ONTWERP_DIR . 'inc/header-footer.php';
require_once IPYART_ONTWERP_DIR . 'inc/nieuwsbrief.php';
require_once IPYART_ONTWERP_DIR . 'inc/redirects.php';

register_activation_hook( __FILE__, 'ipyart_ontwerp_activate' );
register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );

function ipyart_ontwerp_activate() {
	ipyart_ontwerp_register_gedicht();
	flush_rewrite_rules();
}

/**
 * Leest een bestand uit de plugin (patronen, templates, onderdelen).
 */
function ipyart_ontwerp_file( $relative ) {
	$path = IPYART_ONTWERP_DIR . ltrim( $relative, '/' );
	return is_readable( $path ) ? (string) file_get_contents( $path ) : '';
}
