<?php
/**
 * Ontwerppatronen in de categorie "IPY ART". De markup staat in patterns/*.html.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', 'ipyart_ontwerp_register_patterns' );

function ipyart_ontwerp_patronen() {
	return array(
		'hero-halve-maan'    => array( 'Hero met halve maan', 'Titel, intro, knoppen en een schilderij in de halvemaanvorm.' ),
		'drieluik'           => array( 'Drieluik: schilderijen, gedichten, muziek', 'Drie kaarten naar de disciplines.' ),
		'licht-en-schaduw'   => array( 'Licht en schaduw', 'Donkere sectie met schilderij en een persoonlijke tekst.' ),
		'aanbod-kaarten'     => array( 'Aanbod-kaarten', 'Drie kaarten met aanbod en prijsindicatie.' ),
		'gedicht-uitgelicht' => array( 'Uitgelicht gedicht', 'Het nieuwste gedicht, automatisch.' ),
		'agenda-item'        => array( 'Agenda-item', 'Datum, titel, plaats en knop.' ),
		'atelier-chalet'     => array( 'Atelier en chalet', 'Twee kaarten: atelierbezoek en het chalet aan de Waddenzee.' ),
		'nieuwsbrief'        => array( 'Nieuwsbrief', 'Aanmeldblok voor de nieuwsbrief.' ),
		'citaat'             => array( 'Citaat', 'Groot citaat in Gotu met naam.' ),
		'reviews'            => array( 'Klantreviews', 'Drie reviews van opdrachtgevers in kaarten.' ),
		'instagram'          => array( 'Instagram', 'Haar Instagram-feed (of een momentopname) met knop naar @ipy.art.' ),
	);
}

function ipyart_ontwerp_register_patterns() {
	register_block_pattern_category( 'ipyart', array( 'label' => 'IPY ART' ) );

	foreach ( ipyart_ontwerp_patronen() as $slug => $meta ) {
		$content = ipyart_ontwerp_file( "patterns/{$slug}.html" );
		if ( '' === $content ) {
			continue;
		}

		register_block_pattern(
			"ipyart/{$slug}",
			array(
				'title'       => $meta[0],
				'description' => $meta[1],
				'categories'  => array( 'ipyart' ),
				'content'     => $content,
			)
		);
	}
}
