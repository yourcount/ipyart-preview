<?php
/**
 * Stijl: extra kleuren, blokstijlen en de CSS van het nieuwe ontwerp.
 */

defined( 'ABSPATH' ) || exit;

/**
 * De extra kleuren. De bestaande kleuren (primary, tertiary, foreground-alt) blijven gewoon bestaan.
 */
function ipyart_ontwerp_kleuren() {
	return array(
		array(
			'slug'  => 'papier',
			'name'  => 'IPY papier',
			'color' => '#f6f2ec',
		),
		array(
			'slug'  => 'houtskool',
			'name'  => 'IPY houtskool',
			'color' => '#1e1c1b',
		),
		array(
			'slug'  => 'goud',
			'name'  => 'IPY goud',
			'color' => '#a8834f',
		),
	);
}

/**
 * Voegt de kleuren toe aan de standaardkleuren, zodat ze in de kleurkiezer staan,
 * los van wat er in de globale stijlen van het thema of de gebruiker is ingesteld.
 */
add_filter( 'wp_theme_json_data_default', 'ipyart_ontwerp_default_palette' );

function ipyart_ontwerp_default_palette( $theme_json ) {
	$data    = $theme_json->get_data();
	$palette = $data['settings']['color']['palette'] ?? array();
	$slugs   = wp_list_pluck( $palette, 'slug' );

	foreach ( ipyart_ontwerp_kleuren() as $kleur ) {
		if ( ! in_array( $kleur['slug'], $slugs, true ) ) {
			$palette[] = $kleur;
		}
	}

	return $theme_json->update_with(
		array(
			'version'  => 3,
			'settings' => array( 'color' => array( 'palette' => $palette ) ),
		)
	);
}

add_action( 'init', 'ipyart_ontwerp_block_styles' );

function ipyart_ontwerp_block_styles() {
	$stijlen = array(
		'core/image'     => array(
			'halve-maan'        => 'Halve maan',
			'halve-maan-rechts' => 'Halve maan (rechts)',
			'boog'              => 'Boog',
		),
		'core/paragraph' => array(
			'gedicht' => 'Gedicht',
			'label'   => 'Label',
		),
		'core/separator' => array(
			'goud' => 'Gouden lijn',
		),
		'core/group'     => array(
			'kaart' => 'Kaart',
		),
		'core/quote'     => array(
			'ipyart' => 'IPY citaat',
		),
	);

	foreach ( $stijlen as $block => $styles ) {
		foreach ( $styles as $name => $label ) {
			register_block_style(
				$block,
				array(
					'name'  => $name,
					'label' => $label,
				)
			);
		}
	}
}

/**
 * Versie op basis van de bestandsdatum, zodat browsers na een update meteen de nieuwe CSS laden.
 */
function ipyart_ontwerp_css_versie() {
	return IPYART_ONTWERP_VERSION . '.' . (int) filemtime( IPYART_ONTWERP_DIR . 'assets/ontwerp.css' );
}

/**
 * Frontend: alleen als het ontwerp actief is (live, of preview voor beheerders).
 */
add_action( 'wp_enqueue_scripts', 'ipyart_ontwerp_enqueue', 20 );

function ipyart_ontwerp_enqueue() {
	if ( ! ipyart_ontwerp_actief() ) {
		return;
	}

	wp_enqueue_style( 'ipyart-ontwerp', IPYART_ONTWERP_URL . 'assets/ontwerp.css', array(), ipyart_ontwerp_css_versie() );
	wp_enqueue_script(
		'ipyart-ontwerp',
		IPYART_ONTWERP_URL . 'assets/ontwerp.js',
		array(),
		IPYART_ONTWERP_VERSION . '.' . (int) filemtime( IPYART_ONTWERP_DIR . 'assets/ontwerp.js' ),
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
}

/**
 * Editor: altijd, zodat blokstijlen en kleuren in de editor kloppen.
 */
add_action( 'enqueue_block_assets', 'ipyart_ontwerp_enqueue_editor' );

function ipyart_ontwerp_enqueue_editor() {
	if ( is_admin() ) {
		wp_enqueue_style( 'ipyart-ontwerp', IPYART_ONTWERP_URL . 'assets/ontwerp.css', array(), ipyart_ontwerp_css_versie() );
	}
}
