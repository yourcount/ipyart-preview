<?php
/**
 * Gedichten: eigen contenttype met archief op /gedichten/ en eigen templates.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', 'ipyart_ontwerp_register_gedicht' );

function ipyart_ontwerp_register_gedicht() {
	register_post_type(
		'gedicht',
		array(
			'labels'        => array(
				'name'               => 'Gedichten',
				'singular_name'      => 'Gedicht',
				'add_new'            => 'Nieuw gedicht',
				'add_new_item'       => 'Nieuw gedicht toevoegen',
				'edit_item'          => 'Gedicht bewerken',
				'new_item'           => 'Nieuw gedicht',
				'view_item'          => 'Gedicht bekijken',
				'view_items'         => 'Gedichten bekijken',
				'search_items'       => 'Gedichten zoeken',
				'not_found'          => 'Geen gedichten gevonden',
				'not_found_in_trash' => 'Geen gedichten in de prullenbak',
				'all_items'          => 'Alle gedichten',
				'menu_name'          => 'Gedichten',
			),
			'public'        => true,
			'show_in_rest'  => true,
			'menu_icon'     => 'dashicons-format-quote',
			'menu_position' => 21,
			'has_archive'   => 'gedichten',
			'rewrite'       => array(
				'slug'       => 'gedichten',
				'with_front' => false,
			),
			'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'revisions', 'custom-fields' ),
			// Een nieuw gedicht begint met regels in de stijl "Gedicht" en een plek voor een foto van het handschrift.
			'template'      => array(
				array(
					'core/paragraph',
					array(
						'className'   => 'is-style-gedicht',
						'placeholder' => 'Schrijf hier je gedicht. Shift + Enter voor een nieuwe regel, Enter voor een nieuwe strofe.',
					),
				),
			),
		)
	);

	register_post_meta(
		'gedicht',
		'ipyart_jaar',
		array(
			'type'         => 'string',
			'description'  => 'Jaar of moment van schrijven (optioneel).',
			'single'       => true,
			'show_in_rest' => true,
		)
	);
}

/**
 * Zolang het ontwerp niet actief is, zijn de gedichtenpagina's voor bezoekers nog niet zichtbaar (404),
 * zodat er geen half gestylede pagina's online staan. Iris kan intussen wel gedichten toevoegen.
 */
add_action( 'template_redirect', 'ipyart_ontwerp_gate_gedichten' );

function ipyart_ontwerp_gate_gedichten() {
	if ( ( is_post_type_archive( 'gedicht' ) || is_singular( 'gedicht' ) ) && ! ipyart_ontwerp_actief() ) {
		global $wp_query;
		$wp_query->set_404();
		status_header( 404 );
		nocache_headers();
	}
}

/**
 * Templates voor het archief en een los gedicht. Het thema mag ze overschrijven via de Site Editor.
 */
add_action( 'init', 'ipyart_ontwerp_register_gedicht_templates' );

function ipyart_ontwerp_register_gedicht_templates() {
	if ( ! function_exists( 'register_block_template' ) ) {
		return;
	}

	register_block_template(
		'ipyart-ontwerp//archive-gedicht',
		array(
			'title'       => 'Gedichten (archief)',
			'description' => 'Overzicht van alle gedichten.',
			'content'     => ipyart_ontwerp_file( 'templates/archive-gedicht.html' ),
		)
	);

	register_block_template(
		'ipyart-ontwerp//single-gedicht',
		array(
			'title'       => 'Gedicht',
			'description' => 'Een los gedicht.',
			'content'     => ipyart_ontwerp_file( 'templates/single-gedicht.html' ),
			'post_types'  => array( 'gedicht' ),
		)
	);
}
