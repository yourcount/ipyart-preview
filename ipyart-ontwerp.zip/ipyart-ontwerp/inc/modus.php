<?php
/**
 * Modus van het nieuwe ontwerp: uit, preview (alleen beheerders met de preview aan) of live.
 */

defined( 'ABSPATH' ) || exit;

const IPYART_PREVIEW_COOKIE = 'ipyart_preview';

function ipyart_ontwerp_modus() {
	return get_option( 'ipyart_ontwerp_modus', 'preview' );
}

/**
 * Is het nieuwe ontwerp actief voor deze bezoeker?
 */
function ipyart_ontwerp_actief() {
	$modus = ipyart_ontwerp_modus();

	if ( 'live' === $modus ) {
		return true;
	}

	if ( 'preview' === $modus ) {
		return ipyart_ontwerp_preview_aan();
	}

	return false;
}

/**
 * Preview staat aan voor ingelogde redacteuren met de preview-cookie.
 */
function ipyart_ontwerp_preview_aan() {
	return is_user_logged_in()
		&& current_user_can( 'edit_pages' )
		&& ! empty( $_COOKIE[ IPYART_PREVIEW_COOKIE ] );
}

/**
 * ?ipyart-preview=1 of =0 zet de preview aan of uit.
 */
add_action( 'init', 'ipyart_ontwerp_toggle_preview' );

function ipyart_ontwerp_toggle_preview() {
	if ( ! isset( $_GET['ipyart-preview'] ) || ! is_user_logged_in() || ! current_user_can( 'edit_pages' ) ) {
		return;
	}

	$aan = '1' === $_GET['ipyart-preview'];
	setcookie( IPYART_PREVIEW_COOKIE, $aan ? '1' : '', $aan ? time() + MONTH_IN_SECONDS : time() - HOUR_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
	$_COOKIE[ IPYART_PREVIEW_COOKIE ] = $aan ? '1' : '';

	wp_safe_redirect( remove_query_arg( 'ipyart-preview' ) );
	exit;
}

/**
 * Knop in de adminbalk om de preview aan/uit te zetten.
 */
add_action( 'admin_bar_menu', 'ipyart_ontwerp_admin_bar', 90 );

function ipyart_ontwerp_admin_bar( WP_Admin_Bar $bar ) {
	if ( 'preview' !== ipyart_ontwerp_modus() || ! current_user_can( 'edit_pages' ) ) {
		return;
	}

	$aan = ipyart_ontwerp_preview_aan();
	$url = is_admin() ? home_url( '/' ) : ( is_ssl() ? 'https://' : 'http://' ) . ( $_SERVER['HTTP_HOST'] ?? '' ) . ( $_SERVER['REQUEST_URI'] ?? '/' );

	$bar->add_node(
		array(
			'id'    => 'ipyart-preview',
			'title' => $aan ? 'Nieuw ontwerp: aan' : 'Nieuw ontwerp: uit',
			'href'  => add_query_arg( 'ipyart-preview', $aan ? '0' : '1', $url ),
			'meta'  => array( 'title' => 'Alleen jij ziet dit; bezoekers zien de huidige site.' ),
		)
	);
}
