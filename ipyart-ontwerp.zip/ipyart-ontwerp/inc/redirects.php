<?php
/**
 * Doorverwijzingen voor URL's die door het nieuwe ontwerp veranderen.
 * WordPress stuurt oude slugs van pagina's niet zelf door (alleen van berichten).
 */

defined( 'ABSPATH' ) || exit;

function ipyart_ontwerp_redirects() {
	return apply_filters(
		'ipyart_ontwerp_redirects',
		array(
			'media-en-events' => '/agenda/',
		)
	);
}

add_action( 'template_redirect', 'ipyart_ontwerp_redirect_old_urls', 1 );

function ipyart_ontwerp_redirect_old_urls() {
	if ( ! is_404() || 'live' !== ipyart_ontwerp_modus() ) {
		return;
	}

	$path = trim( (string) wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ), '/' );
	$map  = ipyart_ontwerp_redirects();

	if ( isset( $map[ $path ] ) ) {
		wp_safe_redirect( home_url( $map[ $path ] ), 301 );
		exit;
	}
}
