<?php
/**
 * Eenvoudig beheer van het beheer.
 *
 * Iris blijft beheerder met alle rechten. De eenvoudig beheer verbergt alleen wat ze zelden nodig heeft
 * en toont een welkomstscherm met grote knoppen. Wisselen kan altijd via de adminbalk ("Beheer").
 * Er wordt niets geblokkeerd: via een directe URL blijft alles bereikbaar.
 */

defined( 'ABSPATH' ) || exit;

const IPYART_WEERGAVE_META = 'ipyart_weergave';

function ipyart_ontwerp_eenvoudig() {
	return is_user_logged_in() && 'volledig' !== get_user_meta( get_current_user_id(), IPYART_WEERGAVE_META, true );
}

/* ---------- Wisselen ---------- */

add_action( 'init', 'ipyart_ontwerp_weergave_wisselen' );

function ipyart_ontwerp_weergave_wisselen() {
	if ( ! isset( $_GET['ipyart-weergave'] ) || ! is_user_logged_in() ) {
		return;
	}
	if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'ipyart-weergave' ) ) {
		return;
	}

	$nieuw = 'volledig' === $_GET['ipyart-weergave'] ? 'volledig' : 'eenvoudig';
	update_user_meta( get_current_user_id(), IPYART_WEERGAVE_META, $nieuw );

	wp_safe_redirect( 'eenvoudig' === $nieuw && is_admin() ? admin_url() : remove_query_arg( array( 'ipyart-weergave', '_wpnonce' ) ) );
	exit;
}

add_action( 'admin_bar_menu', 'ipyart_ontwerp_weergave_knop', 80 );

function ipyart_ontwerp_weergave_knop( WP_Admin_Bar $bar ) {
	if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
		return;
	}

	$eenvoudig = ipyart_ontwerp_eenvoudig();
	$huidig    = is_admin() ? ( is_ssl() ? 'https://' : 'http://' ) . ( $_SERVER['HTTP_HOST'] ?? '' ) . ( $_SERVER['REQUEST_URI'] ?? '' ) : ( is_ssl() ? 'https://' : 'http://' ) . ( $_SERVER['HTTP_HOST'] ?? '' ) . ( $_SERVER['REQUEST_URI'] ?? '/' );
	$url       = wp_nonce_url( add_query_arg( 'ipyart-weergave', $eenvoudig ? 'volledig' : 'eenvoudig', remove_query_arg( array( 'ipyart-weergave', '_wpnonce' ), $huidig ) ), 'ipyart-weergave' );

	$bar->add_node(
		array(
			'id'    => 'ipyart-weergave',
			'title' => $eenvoudig ? 'Beheer: eenvoudig' : 'Beheer: volledig',
			'href'  => $url,
			'meta'  => array( 'title' => $eenvoudig ? 'Klik voor de volledig beheer met alle opties' : 'Klik voor de eenvoudig beheer' ),
		)
	);
}

/* ---------- Opschonen ---------- */

add_action( 'admin_bar_menu', 'ipyart_ontwerp_adminbalk_opschonen', 999 );

function ipyart_ontwerp_adminbalk_opschonen( WP_Admin_Bar $bar ) {
	if ( ! ipyart_ontwerp_eenvoudig() ) {
		return;
	}
	foreach ( array( 'wp-logo', 'comments', 'updates', 'new-post', 'new-user', 'new-media', 'wpforms-menu', 'customize', 'site-editor' ) as $id ) {
		$bar->remove_node( $id );
	}
}

add_action( 'admin_menu', 'ipyart_ontwerp_menu_opschonen', 999 );

function ipyart_ontwerp_menu_opschonen() {
	add_menu_page( 'Hulp', 'Hulp', 'edit_posts', 'ipyart-hulp', 'ipyart_ontwerp_hulp_pagina', 'dashicons-editor-help', 90 );

	if ( ! ipyart_ontwerp_eenvoudig() ) {
		return;
	}

	foreach ( array( 'edit.php', 'edit-comments.php', 'tools.php', 'options-general.php', 'plugins.php', 'themes.php', 'users.php', 'wpforms-overview', 'edit.php?post_type=wpforms', 'separator1' ) as $slug ) {
		remove_menu_page( $slug );
	}
}

add_filter( 'admin_body_class', function ( $classes ) {
	return ipyart_ontwerp_eenvoudig() ? $classes . ' ipyart-eenvoudig' : $classes;
} );

/* Meldingen en reclame van plugins verbergen; fouten blijven zichtbaar. */
add_action( 'admin_head', function () {
	if ( ! ipyart_ontwerp_eenvoudig() ) {
		return;
	}
	echo '<style>.notice-info,.notice-warning,.update-nag,.wpforms-notice,#wpforms-notice-bar,.gt-notice{display:none!important}</style>';
} );

/* ---------- Dashboard ---------- */

add_action( 'wp_dashboard_setup', 'ipyart_ontwerp_dashboard', 999 );

function ipyart_ontwerp_dashboard() {
	if ( ! ipyart_ontwerp_eenvoudig() ) {
		return;
	}

	global $wp_meta_boxes;
	$wp_meta_boxes['dashboard'] = array();
	remove_action( 'welcome_panel', 'wp_welcome_panel' );

	wp_add_dashboard_widget( 'ipyart_welkom', 'Welkom', 'ipyart_ontwerp_welkom_widget' );
}

add_filter( 'get_user_option_screen_layout_dashboard', function ( $layout ) {
	return ipyart_ontwerp_eenvoudig() ? 1 : $layout;
} );

function ipyart_ontwerp_tel( $type ) {
	$c = wp_count_posts( $type );
	return isset( $c->publish ) ? (int) $c->publish : 0;
}

function ipyart_ontwerp_welkom_widget() {
	$naam  = wp_get_current_user()->display_name;
	$modus = ipyart_ontwerp_modus();

	$knoppen = array(
		array( 'dashicons-format-quote', 'Nieuw gedicht', 'Schrijf een gedicht', admin_url( 'post-new.php?post_type=gedicht' ) ),
		array( 'dashicons-art', 'Nieuw werk', 'Voeg een schilderij toe', admin_url( 'post-new.php?post_type=werk' ) ),
		array( 'dashicons-calendar-alt', 'Nieuw agenda-item', 'Expositie of evenement', admin_url( 'post-new.php?post_type=agenda_item' ) ),
		array( 'dashicons-format-chat', 'Nieuwe review', 'Wat een klant over je zei', admin_url( 'post-new.php?post_type=review' ) ),
		array( 'dashicons-admin-page', 'Een pagina aanpassen', 'Teksten en foto’s wijzigen', admin_url( 'edit.php?post_type=page' ) ),
		array( 'dashicons-admin-media', 'Foto’s en bestanden', 'Uploaden en beheren', admin_url( 'upload.php' ) ),
		array( 'dashicons-email-alt', 'Nieuwsbrief', 'Naar MailerLite', 'https://dashboard.mailerlite.com/' ),
		array( 'dashicons-visibility', 'Bekijk de website', 'Zoals bezoekers hem zien', home_url( '/' ) ),
		array( 'dashicons-editor-help', 'Hulp', 'Korte uitleg in gewoon Nederlands', admin_url( 'admin.php?page=ipyart-hulp' ) ),
	);

	echo '<div class="ipyart-welkom">';
	printf( '<p class="ipyart-welkom__hoi">Hoi %s, wat wil je doen?</p>', esc_html( $naam ) );
	echo '<div class="ipyart-welkom__tegels">';
	foreach ( $knoppen as $k ) {
		$extern = 0 === strpos( $k[3], 'https://dashboard.mailerlite' ) ? ' target="_blank" rel="noopener"' : '';
		printf(
			'<a class="ipyart-tegel" href="%1$s"%5$s><span class="dashicons %2$s" aria-hidden="true"></span><strong>%3$s</strong><span>%4$s</span></a>',
			esc_url( $k[3] ),
			esc_attr( $k[0] ),
			esc_html( $k[1] ),
			esc_html( $k[2] ),
			$extern // phpcs:ignore WordPress.Security.EscapeOutput
		);
	}
	echo '</div>';

	printf(
		'<p class="ipyart-welkom__tellers">Op je site: <strong>%d</strong> werken · <strong>%d</strong> gedichten · <strong>%d</strong> agenda-items · <strong>%d</strong> reviews</p>',
		ipyart_ontwerp_tel( 'werk' ),
		ipyart_ontwerp_tel( 'gedicht' ),
		ipyart_ontwerp_tel( 'agenda_item' ),
		ipyart_ontwerp_tel( 'review' )
	);

	if ( 'preview' === $modus ) {
		echo '<p class="ipyart-welkom__noot">Het nieuwe ontwerp staat in <strong>preview</strong>: alleen jij ziet het, via de knop “Nieuw ontwerp” bovenin. Bezoekers zien nog de huidige site.</p>';
	}
	echo '<p class="ipyart-welkom__noot">Je bent beheerder en kunt alles. Dit is de <strong>eenvoudig beheer</strong>; klik bovenin op <em>Beheer</em> om alle opties te zien.</p>';
	echo '</div>';
}

/* ---------- Hulp ---------- */

function ipyart_ontwerp_hulp_pagina() {
	?>
	<div class="wrap ipyart-hulp">
		<h1>Hulp</h1>
		<p>Korte uitleg voor het meest voorkomende werk. Alles wat je invult verschijnt vanzelf op de juiste plek op de website.</p>

		<h2>Een gedicht toevoegen</h2>
		<ol>
			<li>Klik links op <strong>Gedichten → Nieuw gedicht</strong>.</li>
			<li>Vul de <strong>titel</strong> in en schrijf het gedicht. Een nieuwe regel maak je met <kbd>Shift</kbd> + <kbd>Enter</kbd>, een nieuwe strofe met <kbd>Enter</kbd>.</li>
			<li>Wil je een foto van het handschrift tonen? Kies rechts <strong>Uitgelichte afbeelding</strong>.</li>
			<li>Klik op <strong>Publiceren</strong>. Het gedicht staat dan op <em>/gedichten/</em> en het nieuwste gedicht ook op de homepage.</li>
		</ol>

		<h2>Een schilderij toevoegen</h2>
		<ol>
			<li>Klik op <strong>Werk → Nieuw werk</strong>.</li>
			<li>Vul de <strong>titel</strong> in, kies rechts <strong>de foto van het werk</strong> en vink onderaan de <strong>serie</strong> aan.</li>
			<li>Vul het formaat (bijvoorbeeld 30×40) en de status in. Bij een opdracht kies je ook de <strong>referentiefoto</strong>.</li>
			<li>Klik op <strong>Publiceren</strong>. Nieuw werk staat automatisch vooraan.</li>
		</ol>

		<h2>Een expositie of evenement toevoegen</h2>
		<ol>
			<li>Klik op <strong>Agenda → Nieuw agenda-item</strong>.</li>
			<li>Vul de titel, de datum, de locatie en een korte tekst in.</li>
			<li>Klik op <strong>Publiceren</strong>. Het eerstvolgende item staat op de homepage; na de einddatum schuift het vanzelf naar <em>Eerder</em>.</li>
		</ol>

		<h2>Een review toevoegen</h2>
		<ol>
			<li>Klik op <strong>Reviews → Nieuwe review</strong>.</li>
			<li>Zet bovenaan de <strong>naam</strong> van wie de review schreef en plak de tekst bij <strong>De review</strong>.</li>
			<li>Klik op <strong>Publiceren</strong>. De nieuwste reviews staan op de homepage, bij het aanbod, bij Commissies en bij In opdracht.</li>
		</ol>

		<h2>Een tekst of foto op een pagina aanpassen</h2>
		<ol>
			<li>Klik op <strong>Pagina’s</strong> en kies de pagina.</li>
			<li>Klik op de tekst die je wilt wijzigen en typ. Op een foto klikken en <strong>Vervangen</strong> kiezen werkt hetzelfde.</li>
			<li>Klik rechtsboven op <strong>Bijwerken</strong>.</li>
		</ol>
		<p><em>Wil je een stuk toevoegen of verplaatsen? Klik bovenin op <strong>Beheer</strong> en kies de volledig beheer.</em></p>

		<h2>Foto’s</h2>
		<p>Maak foto’s niet kleiner voordat je ze uploadt; de website verkleint ze zelf. Typ bij <strong>Alternatieve tekst</strong> kort wat er op de foto te zien is, bijvoorbeeld “Schilderij van twee geliefden in een omhelzing”. Dat helpt mensen die niet goed zien en vindbaarheid in Google.</p>

		<h2>Nieuwsbrief</h2>
		<p>Nieuwsbrieven maak je in MailerLite (knop <em>Nieuwsbrief</em> op het beginscherm). Aanmeldingen vanaf de website komen daar vanzelf in je lijst.</p>

		<h2>Eenvoudig of volledig beheer</h2>
		<p>Bovenin zie je <strong>Beheer: eenvoudig</strong>. Klik erop voor de volledig beheer met alle opties, en nog een keer om terug te gaan. Je bent in beide gevallen beheerder.</p>
	</div>
	<?php
}

/* ---------- Editor: rustig en overzichtelijk ---------- */

add_filter( 'allowed_block_types_all', 'ipyart_ontwerp_toegestane_blokken', 10, 2 );

function ipyart_ontwerp_toegestane_blokken( $allowed, $context ) {
	if ( ! ipyart_ontwerp_eenvoudig() || ( isset( $context->name ) && 'core/edit-site' === $context->name ) ) {
		return $allowed;
	}

	return array(
		'core/paragraph',
		'core/heading',
		'core/image',
		'core/gallery',
		'core/list',
		'core/list-item',
		'core/quote',
		'core/buttons',
		'core/button',
		'core/columns',
		'core/column',
		'core/group',
		'core/separator',
		'core/spacer',
		'core/audio',
		'core/video',
		'core/embed',
		'core/shortcode',
		'core/more',
	);
}

add_action( 'init', 'ipyart_ontwerp_patronen_opschonen', 99 );

function ipyart_ontwerp_patronen_opschonen() {
	if ( ! is_admin() && ! ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
		return;
	}
	if ( ! ipyart_ontwerp_eenvoudig() ) {
		return;
	}

	$registry = WP_Block_Patterns_Registry::get_instance();
	foreach ( $registry->get_all_registered() as $pattern ) {
		if ( 0 !== strpos( $pattern['name'], 'ipyart/' ) ) {
			$registry->unregister( $pattern['name'] );
		}
	}
}

/* Pagina's: alleen inhoud bewerken. Opbouw wijzigen kan in de volledig beheer. */
add_filter( 'block_editor_settings_all', 'ipyart_ontwerp_pagina_slot', 10, 2 );

function ipyart_ontwerp_pagina_slot( $settings, $context ) {
	if ( ipyart_ontwerp_eenvoudig() && ! empty( $context->post ) && 'page' === $context->post->post_type ) {
		$settings['templateLock'] = 'contentOnly';
	}
	return $settings;
}

add_action( 'admin_notices', 'ipyart_ontwerp_pagina_melding' );

function ipyart_ontwerp_pagina_melding() {
	$screen = get_current_screen();
	if ( ! ipyart_ontwerp_eenvoudig() || ! $screen || 'page' !== $screen->post_type || 'post' !== $screen->base ) {
		return;
	}
	echo '<div class="notice notice-success ipyart-pagina-melding" style="display:block!important"><p><strong>Eenvoudig beheer.</strong> Je kunt teksten en foto’s aanpassen. Wil je de opbouw wijzigen (een stuk toevoegen of verplaatsen)? Klik bovenin op <em>Beheer</em> voor de volledig beheer.</p></div>';
}

/* Grote foto's verkleinen bij het uploaden (WordPress doet dit al boven 2560px). */
add_filter( 'big_image_size_threshold', function () {
	return 2000;
} );
