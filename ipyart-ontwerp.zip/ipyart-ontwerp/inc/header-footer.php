<?php
/**
 * Header en footer van het nieuwe ontwerp.
 *
 * In preview worden de bestaande header en footer vervangen door parts/header.html en parts/footer.html,
 * zonder iets in de database te wijzigen. Bij "live" schrijft het deployscript deze onderdelen naar de
 * templateonderdelen van het thema, zodat ze daarna gewoon in de Site Editor te bewerken zijn.
 */

defined( 'ABSPATH' ) || exit;

add_filter( 'pre_render_block', 'ipyart_ontwerp_swap_template_parts', 10, 2 );

function ipyart_ontwerp_swap_template_parts( $pre_render, $parsed_block ) {
	if ( null !== $pre_render || 'core/template-part' !== ( $parsed_block['blockName'] ?? '' ) ) {
		return $pre_render;
	}

	if ( 'preview' !== ipyart_ontwerp_modus() || ! ipyart_ontwerp_preview_aan() ) {
		return $pre_render;
	}

	$slug = $parsed_block['attrs']['slug'] ?? '';
	if ( ! in_array( $slug, array( 'header', 'footer' ), true ) ) {
		return $pre_render;
	}

	static $busy = false;
	if ( $busy ) {
		return $pre_render;
	}

	$markup = ipyart_ontwerp_file( "parts/{$slug}.html" );
	if ( '' === $markup ) {
		return $pre_render;
	}

	$busy    = true;
	// Net als core/template-part: eerst blokken, dan shortcodes (taalkiezer, nieuwsbriefformulier).
	$content = do_shortcode( shortcode_unautop( do_blocks( $markup ) ) );
	$busy    = false;

	$tag = 'header' === $slug ? 'header' : 'footer';

	return sprintf( '<%1$s class="wp-block-template-part ipyart-%2$s">%3$s</%1$s>', $tag, $slug, $content );
}

/**
 * Taalkiezer: de site is Nederlands, met alleen Engels als alternatief.
 * Zet GTranslate (als het actief is) vast op NL met NL + EN, en laat het menu naar beneden openen
 * (de header zit bovenaan, omhoog openen valt buiten beeld). Aanpasbaar met de filter ipyart_talen.
 */
add_filter( 'option_GTranslate', 'ipyart_ontwerp_gtranslate_instellingen' );

function ipyart_ontwerp_gtranslate_instellingen( $opties ) {
	if ( ! is_array( $opties ) || ! function_exists( 'ipyart_ontwerp_actief' ) || is_admin() || ! ipyart_ontwerp_actief() ) {
		return $opties;
	}

	$talen = apply_filters( 'ipyart_talen', array( 'nl', 'en' ) );

	$opties['default_language']              = $talen[0];
	$opties['incl_langs']                    = $talen;
	$opties['fincl_langs']                   = $talen;
	$opties['float_switcher_open_direction'] = 'bottom';
	$opties['switcher_open_direction']       = 'bottom';

	return $opties;
}

/**
 * [ipyart_taal]: de taalkiezer van GTranslate, alleen als die plugin actief is.
 */
add_shortcode( 'ipyart_taal', 'ipyart_ontwerp_taal_shortcode' );

function ipyart_ontwerp_taal_shortcode() {
	if ( ! shortcode_exists( 'gtranslate' ) ) {
		return '';
	}

	return '<div class="ipyart-taal">' . do_shortcode( '[gtranslate]' ) . '</div>';
}
