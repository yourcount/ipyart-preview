<?php
/**
 * Header en footer van het nieuwe ontwerp.
 *
 * In preview worden de bestaande header en footer vervangen door parts/header.html en parts/footer.html,
 * zonder iets in de database te wijzigen. Bij "live" schrijft het deployscript deze onderdelen naar de
 * templateonderdelen van het thema, zodat ze daarna gewoon in de Site Editor te bewerken zijn.
 */

defined( 'ABSPATH' ) || exit;

add_filter( 'pre_render_block', 'ipyart_ontwerp_swap_template_parts', 10, 2 );

function ipyart_ontwerp_swap_template_parts( $pre_render, $parsed_block ) {
	if ( null !== $pre_render || 'core/template-part' !== ( $parsed_block['blockName'] ?? '' ) ) {
		return $pre_render;
	}

	if ( 'preview' !== ipyart_ontwerp_modus() || ! ipyart_ontwerp_preview_aan() ) {
		return $pre_render;
	}

	$slug = $parsed_block['attrs']['slug'] ?? '';
	if ( ! in_array( $slug, array( 'header', 'footer' ), true ) ) {
		return $pre_render;
	}

	static $busy = false;
	if ( $busy ) {
		return $pre_render;
	}

	$markup = ipyart_ontwerp_file( "parts/{$slug}.html" );
	if ( '' === $markup ) {
		return $pre_render;
	}

	$busy    = true;
	// Net als core/template-part: eerst blokken, dan shortcodes (taalkiezer, nieuwsbriefformulier).
	$content = do_shortcode( shortcode_unautop( do_blocks( $markup ) ) );
	$busy    = false;

	$tag = 'header' === $slug ? 'header' : 'footer';

	return sprintf( '<%1$s class="wp-block-template-part ipyart-%2$s">%3$s</%1$s>', $tag, $slug, $content );
}

/**
 * [ipyart_taal]: de taalkiezer van GTranslate, alleen als die plugin actief is.
 */
add_shortcode( 'ipyart_taal', 'ipyart_ontwerp_taal_shortcode' );

function ipyart_ontwerp_taal_shortcode() {
	if ( ! shortcode_exists( 'gtranslate' ) ) {
		return '';
	}

	return '<div class="ipyart-taal">' . do_shortcode( '[gtranslate]' ) . '</div>';
}
