<?php
/**
 * Inhoud als formulier: Werk (schilderijen en opdrachten) en Agenda.
 *
 * Iris vult een formulier in; de pagina's tonen de inhoud via shortcodes in het bestaande ontwerp:
 *   [ipyart_werk serie="lovers-serie" kolommen="3"]      galerij van een serie
 *   [ipyart_werk serie="opdrachten" paren="ja"]          schilderij naast referentiefoto
 *   [ipyart_agenda toon="komend|eerder"]                 agenda-items
 *   [ipyart_agenda_volgende]                             het eerstvolgende item (homepage)
 *   [ipyart_aantal serie="lovers-serie,portretten"]      aantal werken
 */

defined( 'ABSPATH' ) || exit;

const IPYART_WERK_STATUS = array(
	'beschikbaar' => 'Beschikbaar',
	'verkocht'    => 'Origineel verkocht',
	'print'       => 'Alleen als print',
);

/* ---------- Contenttypes en series ---------- */

add_action( 'init', 'ipyart_ontwerp_register_content', 5 );

function ipyart_ontwerp_register_content() {
	register_post_type(
		'werk',
		array(
			'labels'              => array(
				'name'               => 'Werk',
				'singular_name'      => 'Werk',
				'add_new'            => 'Nieuw werk',
				'add_new_item'       => 'Nieuw werk toevoegen',
				'edit_item'          => 'Werk bewerken',
				'new_item'           => 'Nieuw werk',
				'view_item'          => 'Werk bekijken',
				'search_items'       => 'Werk zoeken',
				'not_found'          => 'Nog geen werk toegevoegd',
				'not_found_in_trash' => 'Geen werk in de prullenbak',
				'all_items'          => 'Al het werk',
				'menu_name'          => 'Werk',
				'featured_image'     => 'Foto van het werk',
				'set_featured_image' => 'Kies de foto van het werk',
				'remove_featured_image' => 'Foto verwijderen',
				'use_featured_image' => 'Gebruik als foto van het werk',
				'enter_title_here'   => 'Titel van het werk',
			),
			'public'              => false,
			'publicly_queryable'  => false,
			'show_ui'             => true,
			'show_in_rest'        => true,
			'show_in_nav_menus'   => false,
			'exclude_from_search' => true,
			'menu_icon'           => 'dashicons-art',
			'menu_position'       => 20,
			'supports'            => array( 'title', 'thumbnail', 'page-attributes', 'custom-fields' ),
			'taxonomies'          => array( 'werk_serie' ),
		)
	);

	register_taxonomy(
		'werk_serie',
		'werk',
		array(
			'labels'            => array(
				'name'          => 'Series',
				'singular_name' => 'Serie',
				'menu_name'     => 'Series',
				'all_items'     => 'Alle series',
				'edit_item'     => 'Serie bewerken',
				'add_new_item'  => 'Nieuwe serie',
			),
			'hierarchical'      => true,
			'public'            => false,
			'show_ui'           => true,
			'show_in_rest'      => true,
			'show_admin_column' => true,
			'default_term'      => array(
				'name' => 'Portretten en momenten',
				'slug' => 'portretten',
			),
		)
	);

	register_post_type(
		'agenda_item',
		array(
			'labels'              => array(
				'name'               => 'Agenda',
				'singular_name'      => 'Agenda-item',
				'add_new'            => 'Nieuw agenda-item',
				'add_new_item'       => 'Nieuw agenda-item toevoegen',
				'edit_item'          => 'Agenda-item bewerken',
				'new_item'           => 'Nieuw agenda-item',
				'search_items'       => 'Agenda zoeken',
				'not_found'          => 'Nog geen agenda-items',
				'not_found_in_trash' => 'Geen agenda-items in de prullenbak',
				'all_items'          => 'Hele agenda',
				'menu_name'          => 'Agenda',
				'featured_image'     => 'Foto (optioneel)',
				'set_featured_image' => 'Kies een foto',
				'enter_title_here'   => 'Titel, bijvoorbeeld de naam van de expositie',
			),
			'public'              => false,
			'publicly_queryable'  => false,
			'show_ui'             => true,
			'show_in_rest'        => true,
			'show_in_nav_menus'   => false,
			'exclude_from_search' => true,
			'menu_icon'           => 'dashicons-calendar-alt',
			'menu_position'       => 22,
			'supports'            => array( 'title', 'thumbnail', 'custom-fields' ),
		)
	);

	register_post_type(
		'review',
		array(
			'labels'              => array(
				'name'               => 'Reviews',
				'singular_name'      => 'Review',
				'add_new'            => 'Nieuwe review',
				'add_new_item'       => 'Nieuwe review toevoegen',
				'edit_item'          => 'Review bewerken',
				'new_item'           => 'Nieuwe review',
				'search_items'       => 'Reviews zoeken',
				'not_found'          => 'Nog geen reviews',
				'not_found_in_trash' => 'Geen reviews in de prullenbak',
				'all_items'          => 'Alle reviews',
				'menu_name'          => 'Reviews',
				'enter_title_here'   => 'Naam van de persoon',
			),
			'public'              => false,
			'publicly_queryable'  => false,
			'show_ui'             => true,
			'show_in_rest'        => true,
			'show_in_nav_menus'   => false,
			'exclude_from_search' => true,
			'menu_icon'           => 'dashicons-format-chat',
			'menu_position'       => 23,
			'supports'            => array( 'title', 'page-attributes', 'custom-fields' ),
		)
	);

	foreach ( array( 'ipyart_review', 'ipyart_review_over' ) as $key ) {
		register_post_meta( 'review', $key, array( 'type' => 'string', 'single' => true, 'show_in_rest' => true ) );
	}

	$werk = array(
		'ipyart_formaat'      => 'string',
		'ipyart_techniek'     => 'string',
		'ipyart_status'       => 'string',
		'ipyart_referentie'   => 'integer',
		'ipyart_foto_extern'  => 'string',
		'ipyart_ref_extern'   => 'string',
	);
	foreach ( $werk as $key => $type ) {
		register_post_meta( 'werk', $key, array( 'type' => $type, 'single' => true, 'show_in_rest' => true ) );
	}

	$agenda = array( 'ipyart_start', 'ipyart_eind', 'ipyart_tijd', 'ipyart_locatie', 'ipyart_soort', 'ipyart_tekst', 'ipyart_extra', 'ipyart_datumtekst', 'ipyart_foto_extern', 'ipyart_video' );
	foreach ( $agenda as $key ) {
		register_post_meta( 'agenda_item', $key, array( 'type' => 'string', 'single' => true, 'show_in_rest' => true ) );
	}
}

add_action( 'init', 'ipyart_ontwerp_ensure_series', 20 );

function ipyart_ontwerp_ensure_series() {
	if ( get_option( 'ipyart_series_klaar' ) ) {
		return;
	}
	foreach ( array(
		'lovers-serie' => 'Lovers-serie',
		'portretten'   => 'Portretten en momenten',
		'opdrachten'   => 'In opdracht',
	) as $slug => $name ) {
		if ( ! term_exists( $slug, 'werk_serie' ) ) {
			wp_insert_term( $name, 'werk_serie', array( 'slug' => $slug ) );
		}
	}
	update_option( 'ipyart_series_klaar', 1 );
}

/* ---------- Formulieren (metaboxen) ---------- */

add_action( 'add_meta_boxes', 'ipyart_ontwerp_metaboxes' );

function ipyart_ontwerp_metaboxes() {
	add_meta_box( 'ipyart_werk', 'Over dit werk', 'ipyart_ontwerp_box_werk', 'werk', 'normal', 'high' );
	add_meta_box( 'ipyart_agenda', 'Wanneer en waar', 'ipyart_ontwerp_box_agenda', 'agenda_item', 'normal', 'high' );
	add_meta_box( 'ipyart_review_box', 'De review', 'ipyart_ontwerp_box_review', 'review', 'normal', 'high' );
	remove_meta_box( 'postcustom', 'review', 'normal' );
	remove_meta_box( 'pageparentdiv', 'review', 'side' );
	remove_meta_box( 'slugdiv', 'review', 'normal' );
	remove_meta_box( 'postcustom', 'werk', 'normal' );
	remove_meta_box( 'postcustom', 'agenda_item', 'normal' );
	remove_meta_box( 'pageparentdiv', 'werk', 'side' );
	remove_meta_box( 'slugdiv', 'werk', 'normal' );
	remove_meta_box( 'slugdiv', 'agenda_item', 'normal' );
}

function ipyart_ontwerp_veld( $label, $name, $post_id, $args = array() ) {
	$value = get_post_meta( $post_id, $name, true );
	$type  = $args['type'] ?? 'text';
	$hulp  = $args['hulp'] ?? '';
	echo '<p class="ipyart-veld"><label for="' . esc_attr( $name ) . '"><strong>' . esc_html( $label ) . '</strong></label><br>';
	if ( 'textarea' === $type ) {
		printf( '<textarea id="%1$s" name="%1$s" rows="3" class="large-text">%2$s</textarea>', esc_attr( $name ), esc_textarea( $value ) );
	} elseif ( 'select' === $type ) {
		printf( '<select id="%1$s" name="%1$s">', esc_attr( $name ) );
		foreach ( $args['opties'] as $k => $l ) {
			printf( '<option value="%s"%s>%s</option>', esc_attr( $k ), selected( $value ?: ( $args['standaard'] ?? '' ), $k, false ), esc_html( $l ) );
		}
		echo '</select>';
	} else {
		printf( '<input type="%1$s" id="%2$s" name="%2$s" value="%3$s" class="%4$s" placeholder="%5$s">', esc_attr( $type ), esc_attr( $name ), esc_attr( $value ), esc_attr( $args['klasse'] ?? 'regular-text' ), esc_attr( $args['placeholder'] ?? '' ) );
	}
	if ( $hulp ) {
		echo '<br><span class="description">' . esc_html( $hulp ) . '</span>';
	}
	echo '</p>';
}

function ipyart_ontwerp_box_werk( $post ) {
	wp_nonce_field( 'ipyart_werk', 'ipyart_werk_nonce' );
	echo '<p class="description">Kies rechts bij <em>Foto van het werk</em> de foto, en vink onderaan bij <em>Series</em> aan waar het bij hoort. Nieuw werk komt automatisch vooraan te staan.</p>';
	ipyart_ontwerp_veld( 'Formaat (cm)', 'ipyart_formaat', $post->ID, array( 'placeholder' => '30×40', 'klasse' => 'small-text', 'hulp' => 'Breedte × hoogte, bijvoorbeeld 30×40.' ) );
	ipyart_ontwerp_veld(
		'Techniek',
		'ipyart_techniek',
		$post->ID,
		array(
			'type'   => 'select',
			'opties' => array(
				''          => '(niet tonen)',
				'Olieverf'  => 'Olieverf',
				'Houtskool' => 'Houtskool',
				'Gemengd'   => 'Gemengde techniek',
			),
		)
	);
	ipyart_ontwerp_veld( 'Status', 'ipyart_status', $post->ID, array( 'type' => 'select', 'opties' => IPYART_WERK_STATUS, 'standaard' => 'beschikbaar' ) );

	$ref = (int) get_post_meta( $post->ID, 'ipyart_referentie', true );
	echo '<div class="ipyart-foto-veld"><p><strong>Referentiefoto</strong> <span class="description">(alleen bij opdrachten: de foto waarvan je het schilderij maakte)</span></p>';
	echo '<div class="ipyart-foto-voorbeeld">' . ( $ref ? wp_get_attachment_image( $ref, 'thumbnail' ) : '' ) . '</div>';
	printf( '<input type="hidden" name="ipyart_referentie" value="%d">', $ref );
	echo '<button type="button" class="button ipyart-kies-foto">Kies referentiefoto</button> ';
	printf( '<button type="button" class="button-link ipyart-verwijder-foto"%s>Verwijderen</button></div>', $ref ? '' : ' style="display:none"' );

	printf(
		'<p class="ipyart-veld"><label for="ipyart_volgorde"><strong>Volgorde (optioneel)</strong></label><br><input type="number" min="0" id="ipyart_volgorde" name="ipyart_volgorde" value="%d" class="small-text"><br><span class="description">0: nieuw werk staat vooraan. Een hoger getal zet het verder naar achteren.</span></p>',
		(int) $post->menu_order
	);
}

function ipyart_ontwerp_box_agenda( $post ) {
	wp_nonce_field( 'ipyart_agenda', 'ipyart_agenda_nonce' );
	echo '<p class="description">Het eerstvolgende item staat automatisch op de homepage. Na de einddatum schuift het vanzelf naar “Eerder”.</p>';
	ipyart_ontwerp_veld( 'Soort', 'ipyart_soort', $post->ID, array( 'placeholder' => 'Solo-expositie', 'hulp' => 'Bijvoorbeeld: Solo-expositie, Workshop, Release.' ) );
	echo '<div class="ipyart-twee">';
	ipyart_ontwerp_veld( 'Begindatum', 'ipyart_start', $post->ID, array( 'type' => 'date', 'klasse' => '' ) );
	ipyart_ontwerp_veld( 'Einddatum', 'ipyart_eind', $post->ID, array( 'type' => 'date', 'klasse' => '', 'hulp' => 'Leeg laten als het één dag is.' ) );
	echo '</div>';
	ipyart_ontwerp_veld( 'Tijd', 'ipyart_tijd', $post->ID, array( 'placeholder' => '16:00 – 20:00' ) );
	ipyart_ontwerp_veld( 'Locatie', 'ipyart_locatie', $post->ID, array( 'placeholder' => 'Appie Gallery, Amsterdam' ) );
	ipyart_ontwerp_veld( 'Korte tekst', 'ipyart_tekst', $post->ID, array( 'type' => 'textarea' ) );
	ipyart_ontwerp_veld( 'Extra regel (optioneel)', 'ipyart_extra', $post->ID, array( 'placeholder' => 'Art+music borrel: zaterdag 14 november, 16:00 – 20:00' ) );
	ipyart_ontwerp_veld( 'Video (optioneel)', 'ipyart_video', $post->ID, array( 'placeholder' => 'https://vimeo.com/1048871034', 'hulp' => 'Plak de Vimeo-link; de video verschijnt bij dit agenda-item.' ) );
	ipyart_ontwerp_veld( 'Eigen datumtekst (optioneel)', 'ipyart_datumtekst', $post->ID, array( 'placeholder' => '2020', 'klasse' => 'small-text', 'hulp' => 'Alleen invullen als je geen exacte datum hebt; vervangt de datum.' ) );
}

function ipyart_ontwerp_box_review( $post ) {
	wp_nonce_field( 'ipyart_review', 'ipyart_review_nonce' );
	echo '<p class="description">Vul bovenaan de naam in van wie de review schreef. Reviews staan op de homepage, bij het aanbod, bij Commissies en bij In opdracht (de nieuwste eerst; een hogere volgorde zet een review verder naar achteren).</p>';
	ipyart_ontwerp_veld( 'De review', 'ipyart_review', $post->ID, array( 'type' => 'textarea', 'hulp' => 'De tekst van de review, zonder aanhalingstekens.' ) );
	ipyart_ontwerp_veld( 'Waarover (optioneel)', 'ipyart_review_over', $post->ID, array( 'placeholder' => 'Over het schilderij van Suzhou', 'hulp' => 'Een korte regel onder de naam.' ) );
	printf(
		'<p class="ipyart-veld"><label for="ipyart_volgorde"><strong>Volgorde (optioneel)</strong></label><br><input type="number" min="0" id="ipyart_volgorde" name="ipyart_volgorde" value="%d" class="small-text"></p>',
		(int) $post->menu_order
	);
}

add_action( 'save_post_review', 'ipyart_ontwerp_save_review' );

function ipyart_ontwerp_save_review( $post_id ) {
	if ( ! isset( $_POST['ipyart_review_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ipyart_review_nonce'] ) ), 'ipyart_review' ) || ! current_user_can( 'edit_post', $post_id ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ) {
		return;
	}
	update_post_meta( $post_id, 'ipyart_review', sanitize_textarea_field( wp_unslash( $_POST['ipyart_review'] ?? '' ) ) );
	update_post_meta( $post_id, 'ipyart_review_over', sanitize_text_field( wp_unslash( $_POST['ipyart_review_over'] ?? '' ) ) );

	global $wpdb;
	$wpdb->update( $wpdb->posts, array( 'menu_order' => absint( $_POST['ipyart_volgorde'] ?? 0 ) ), array( 'ID' => $post_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	clean_post_cache( $post_id );
}

add_shortcode( 'ipyart_reviews', 'ipyart_ontwerp_reviews_shortcode' );

/**
 * [ipyart_reviews aantal="3"]: de reviews als kaarten.
 */
function ipyart_ontwerp_reviews_shortcode( $atts ) {
	$atts  = shortcode_atts( array( 'aantal' => '3' ), $atts, 'ipyart_reviews' );
	$posts = get_posts(
		array(
			'post_type'      => 'review',
			'post_status'    => 'publish',
			'posts_per_page' => max( 1, (int) $atts['aantal'] ),
			'orderby'        => array( 'menu_order' => 'ASC', 'date' => 'DESC' ),
			'no_found_rows'  => true,
		)
	);

	if ( ! $posts ) {
		return '';
	}

	$out = '<div class="ipyart-reviews">';
	foreach ( $posts as $p ) {
		$tekst = get_post_meta( $p->ID, 'ipyart_review', true );
		$over  = get_post_meta( $p->ID, 'ipyart_review_over', true );
		$out  .= '<figure class="ipyart-review is-style-kaart"><blockquote><p>“' . esc_html( $tekst ) . '”</p></blockquote>'
			. '<figcaption><span class="is-style-label">' . esc_html( get_the_title( $p ) ) . '</span>'
			. ( $over ? '<span class="ipyart-review__over">' . esc_html( $over ) . '</span>' : '' ) . '</figcaption></figure>';
	}
	return $out . '</div>';
}

add_action( 'save_post_werk', 'ipyart_ontwerp_save_werk' );

function ipyart_ontwerp_save_werk( $post_id ) {
	if ( ! isset( $_POST['ipyart_werk_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ipyart_werk_nonce'] ) ), 'ipyart_werk' ) || ! current_user_can( 'edit_post', $post_id ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ) {
		return;
	}

	update_post_meta( $post_id, 'ipyart_formaat', sanitize_text_field( wp_unslash( $_POST['ipyart_formaat'] ?? '' ) ) );
	update_post_meta( $post_id, 'ipyart_techniek', sanitize_text_field( wp_unslash( $_POST['ipyart_techniek'] ?? '' ) ) );
	$status = sanitize_key( wp_unslash( $_POST['ipyart_status'] ?? 'beschikbaar' ) );
	update_post_meta( $post_id, 'ipyart_status', isset( IPYART_WERK_STATUS[ $status ] ) ? $status : 'beschikbaar' );
	update_post_meta( $post_id, 'ipyart_referentie', absint( $_POST['ipyart_referentie'] ?? 0 ) );

	global $wpdb;
	$volgorde = isset( $_POST['ipyart_volgorde'] ) ? absint( $_POST['ipyart_volgorde'] ) : 0;
	$wpdb->update( $wpdb->posts, array( 'menu_order' => $volgorde ), array( 'ID' => $post_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	clean_post_cache( $post_id );
}

add_action( 'save_post_agenda_item', 'ipyart_ontwerp_save_agenda' );

function ipyart_ontwerp_save_agenda( $post_id ) {
	if ( ! isset( $_POST['ipyart_agenda_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ipyart_agenda_nonce'] ) ), 'ipyart_agenda' ) || ! current_user_can( 'edit_post', $post_id ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ) {
		return;
	}

	foreach ( array( 'ipyart_soort', 'ipyart_tijd', 'ipyart_locatie', 'ipyart_extra', 'ipyart_datumtekst', 'ipyart_video' ) as $key ) {
		update_post_meta( $post_id, $key, sanitize_text_field( wp_unslash( $_POST[ $key ] ?? '' ) ) );
	}
	update_post_meta( $post_id, 'ipyart_tekst', sanitize_textarea_field( wp_unslash( $_POST['ipyart_tekst'] ?? '' ) ) );
	foreach ( array( 'ipyart_start', 'ipyart_eind' ) as $key ) {
		$d = sanitize_text_field( wp_unslash( $_POST[ $key ] ?? '' ) );
		update_post_meta( $post_id, $key, preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) ? $d : '' );
	}
}

add_action( 'admin_enqueue_scripts', 'ipyart_ontwerp_admin_assets' );

function ipyart_ontwerp_admin_assets( $hook ) {
	$ver = IPYART_ONTWERP_VERSION . '.' . (int) filemtime( IPYART_ONTWERP_DIR . 'assets/admin.css' );
	wp_enqueue_style( 'ipyart-admin', IPYART_ONTWERP_URL . 'assets/admin.css', array(), $ver );

	$screen = get_current_screen();
	if ( $screen && 'werk' === $screen->post_type && in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
		wp_enqueue_media();
		wp_enqueue_script( 'ipyart-admin', IPYART_ONTWERP_URL . 'assets/admin.js', array( 'jquery' ), $ver, true );
	}
}

/* ---------- Overzichtskolommen ---------- */

add_filter( 'manage_werk_posts_columns', function ( $cols ) {
	return array(
		'cb'              => $cols['cb'],
		'ipyart_foto'     => 'Foto',
		'title'           => 'Titel',
		'ipyart_formaat'  => 'Formaat',
		'taxonomy-werk_serie' => 'Serie',
		'ipyart_status'   => 'Status',
	);
} );

add_action( 'manage_werk_posts_custom_column', function ( $col, $id ) {
	if ( 'ipyart_foto' === $col ) {
		echo ipyart_ontwerp_foto_html( $id, 'thumbnail', '' ); // phpcs:ignore WordPress.Security.EscapeOutput
	} elseif ( 'ipyart_formaat' === $col ) {
		echo esc_html( get_post_meta( $id, 'ipyart_formaat', true ) );
	} elseif ( 'ipyart_status' === $col ) {
		$s = get_post_meta( $id, 'ipyart_status', true ) ?: 'beschikbaar';
		echo esc_html( IPYART_WERK_STATUS[ $s ] ?? '' );
	}
}, 10, 2 );

add_filter( 'manage_agenda_item_posts_columns', function ( $cols ) {
	return array(
		'cb'               => $cols['cb'],
		'title'            => 'Titel',
		'ipyart_wanneer'   => 'Wanneer',
		'ipyart_locatie'   => 'Locatie',
	);
} );

add_action( 'manage_agenda_item_posts_custom_column', function ( $col, $id ) {
	if ( 'ipyart_wanneer' === $col ) {
		$d = ipyart_ontwerp_datum( $id );
		echo esc_html( trim( $d['groot'] . ' ' . $d['klein'] ) );
	} elseif ( 'ipyart_locatie' === $col ) {
		echo esc_html( get_post_meta( $id, 'ipyart_locatie', true ) );
	}
}, 10, 2 );

/* ---------- Weergave ---------- */

/**
 * Foto van een werk of agenda-item: de gekozen foto, of (voor de preview) een externe URL.
 */
function ipyart_ontwerp_foto_html( $post_id, $size = 'large', $alt = null ) {
	$alt = null === $alt ? 'Schilderij ' . get_the_title( $post_id ) : $alt;
	if ( has_post_thumbnail( $post_id ) ) {
		return get_the_post_thumbnail( $post_id, $size, array( 'alt' => $alt, 'loading' => 'lazy' ) );
	}
	$ext = get_post_meta( $post_id, 'ipyart_foto_extern', true );
	return $ext ? sprintf( '<img src="%s" alt="%s" loading="lazy">', esc_url( $ext ), esc_attr( $alt ) ) : '';
}

function ipyart_ontwerp_referentie_html( $post_id, $size = 'large' ) {
	$id  = (int) get_post_meta( $post_id, 'ipyart_referentie', true );
	$alt = 'Referentiefoto voor ' . get_the_title( $post_id );
	if ( $id ) {
		return wp_get_attachment_image( $id, $size, false, array( 'alt' => $alt, 'loading' => 'lazy' ) );
	}
	$ext = get_post_meta( $post_id, 'ipyart_ref_extern', true );
	return $ext ? sprintf( '<img src="%s" alt="%s" loading="lazy">', esc_url( $ext ), esc_attr( $alt ) ) : '';
}

function ipyart_ontwerp_werken( $serie ) {
	$slugs = array_filter( array_map( 'trim', explode( ',', (string) $serie ) ) );
	$args  = array(
		'post_type'      => 'werk',
		'post_status'    => 'publish',
		'posts_per_page' => 200,
		'orderby'        => array( 'menu_order' => 'ASC', 'date' => 'DESC' ),
		'no_found_rows'  => true,
	);
	if ( $slugs ) {
		$args['tax_query'] = array( array( 'taxonomy' => 'werk_serie', 'field' => 'slug', 'terms' => $slugs ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
	}
	return get_posts( $args );
}

function ipyart_ontwerp_werk_bijschrift( $id, $met_status = true ) {
	$delen = array_filter(
		array(
			get_post_meta( $id, 'ipyart_formaat', true ),
			get_post_meta( $id, 'ipyart_techniek', true ),
		)
	);
	$status = get_post_meta( $id, 'ipyart_status', true );
	if ( $met_status && $status && 'beschikbaar' !== $status ) {
		$delen[] = strtolower( IPYART_WERK_STATUS[ $status ] ?? '' );
	}
	$regel = $delen ? '<br>' . esc_html( implode( ' · ', $delen ) ) : '';
	return '<strong>' . esc_html( get_the_title( $id ) ) . '</strong>' . $regel;
}

add_shortcode( 'ipyart_werk', 'ipyart_ontwerp_werk_shortcode' );

function ipyart_ontwerp_werk_shortcode( $atts ) {
	$atts  = shortcode_atts( array( 'serie' => '', 'kolommen' => '3', 'paren' => 'nee' ), $atts, 'ipyart_werk' );
	$posts = ipyart_ontwerp_werken( $atts['serie'] );

	if ( ! $posts ) {
		return current_user_can( 'edit_posts' )
			? '<p class="ipyart-nieuwsbrief-leeg">[Nog geen werk in deze serie. Voeg werk toe via Werk → Nieuw werk.]</p>'
			: '';
	}

	$out = '';
	if ( 'ja' === $atts['paren'] ) {
		$out .= '<div class="ipyart-paren">';
		foreach ( $posts as $p ) {
			$foto = ipyart_ontwerp_foto_html( $p->ID, 'large' );
			$ref  = ipyart_ontwerp_referentie_html( $p->ID );
			$maat = get_post_meta( $p->ID, 'ipyart_formaat', true );
			$out .= '<article class="ipyart-paar"><div class="ipyart-paar__beelden">';
			$out .= '<figure>' . $foto . '<figcaption>Schilderij</figcaption></figure>';
			if ( $ref ) {
				$out .= '<figure>' . $ref . '<figcaption>Referentiefoto</figcaption></figure>';
			}
			$out .= '</div><h3>' . esc_html( get_the_title( $p ) ) . '</h3>';
			if ( $maat ) {
				$out .= '<p class="is-style-label">' . esc_html( $maat ) . '</p>';
			}
			$out .= '</article>';
		}
		return $out . '</div>';
	}

	$kolommen = max( 1, min( 5, (int) $atts['kolommen'] ) );
	$out     .= '<div class="ipyart-werken" style="--ipy-kolommen:' . $kolommen . '">';
	foreach ( $posts as $p ) {
		$status = get_post_meta( $p->ID, 'ipyart_status', true );
		$out   .= '<figure class="ipyart-werk-item' . ( 'verkocht' === $status ? ' is-verkocht' : '' ) . '">'
			. ipyart_ontwerp_foto_html( $p->ID, 'large' )
			. '<figcaption>' . ipyart_ontwerp_werk_bijschrift( $p->ID ) . '</figcaption></figure>';
	}
	return $out . '</div>';
}

add_shortcode( 'ipyart_aantal', 'ipyart_ontwerp_aantal_shortcode' );

function ipyart_ontwerp_aantal_shortcode( $atts ) {
	$atts = shortcode_atts( array( 'serie' => '' ), $atts, 'ipyart_aantal' );
	return (string) count( ipyart_ontwerp_werken( $atts['serie'] ) );
}

/* ---------- Video (Vimeo) ---------- */

/**
 * Vimeo-speler (met "do not track") uit een Vimeo-link of nummer. Leeg als er geen geldig nummer is.
 */
function ipyart_ontwerp_video_html( $link, $titel = '' ) {
	if ( ! preg_match( '/(\d{6,})/', (string) $link, $m ) ) {
		return '';
	}
	return sprintf(
		'<figure class="ipyart-video"><div class="ipyart-video__kader"><iframe src="https://player.vimeo.com/video/%1$s?dnt=1" title="%2$s" loading="lazy" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe></div></figure>',
		esc_attr( $m[1] ),
		esc_attr( $titel ?: 'Video' )
	);
}

add_shortcode( 'ipyart_video', 'ipyart_ontwerp_video_shortcode' );

/**
 * [ipyart_video id="1038452279" titel="IPY ART Painting Tribute"]
 */
function ipyart_ontwerp_video_shortcode( $atts ) {
	$atts = shortcode_atts( array( 'id' => '', 'titel' => 'Video' ), $atts, 'ipyart_video' );
	return ipyart_ontwerp_video_html( $atts['id'], $atts['titel'] );
}

/* ---------- Instagram ---------- */

add_action( 'init', 'ipyart_ontwerp_register_instagram_setting' );

function ipyart_ontwerp_register_instagram_setting() {
	register_setting(
		'ipyart_ontwerp',
		'ipyart_instagram_account',
		array(
			'type'              => 'string',
			'description'       => 'Instagram-account-ID uit de plugin Social Feed Gallery (huidige site: 9635030626520229).',
			'default'           => '9635030626520229',
			'sanitize_callback' => function ( $v ) {
				return preg_replace( '/[^0-9]/', '', (string) $v );
			},
			'show_in_rest'      => true,
		)
	);
}

add_shortcode( 'ipyart_instagram', 'ipyart_ontwerp_instagram_shortcode' );

/**
 * [ipyart_instagram]: haar echte feed als de plugin "Social Feed Gallery" (blok qligg/box) actief is,
 * anders een momentopname van de laatste posts (voor previews en als de plugin ontbreekt).
 */
function ipyart_ontwerp_instagram_shortcode() {
	$account = get_option( 'ipyart_instagram_account', '9635030626520229' );

	if ( '' !== $account && WP_Block_Type_Registry::get_instance()->is_registered( 'qligg/box' ) ) {
		$attrs = array(
			'id'         => 'ipyart-insta',
			'account_id' => $account,
			'layout'     => 'carousel',
			'carousel'   => array(
				'slidespv'          => 5,
				'centered_slides'   => false,
				'autoplay'          => false,
				'autoplay_interval' => 3000,
				'navarrows'         => true,
				'navarrows_color'   => '',
				'pagination'        => true,
				'pagination_color'  => '#94a4cf',
			),
			'button'     => array( 'display' => false ),
		);
		$html = do_blocks( '<!-- wp:qligg/box ' . wp_json_encode( $attrs ) . ' /-->' );
		if ( '' !== trim( wp_strip_all_tags( $html ) ) || false !== strpos( $html, 'qligg' ) ) {
			return '<div class="ipyart-insta ipyart-insta--live">' . $html . '</div>';
		}
	}

	$json = IPYART_ONTWERP_DIR . 'assets/instagram/posts.json';
	$data = is_readable( $json ) ? json_decode( (string) file_get_contents( $json ), true ) : array();
	if ( ! $data ) {
		return '';
	}

	$out = '<div class="ipyart-insta"><ul class="ipyart-insta__rij" role="list">';
	foreach ( $data as $post ) {
		$out .= sprintf(
			'<li><a href="%1$s" target="_blank" rel="noopener" aria-label="%2$s"><img src="%3$s" alt="" loading="lazy" decoding="async">%4$s</a></li>',
			esc_url( $post['href'] ),
			esc_attr( ( ! empty( $post['reel'] ) ? 'Bekijk deze reel' : 'Bekijk deze post' ) . ' op Instagram' ),
			esc_url( IPYART_ONTWERP_URL . 'assets/instagram/' . $post['bestand'] ),
			! empty( $post['reel'] ) ? '<span class="ipyart-insta__reel" aria-hidden="true">▶</span>' : ''
		);
	}
	return $out . '</ul></div>';
}

/* ---------- Agenda ---------- */

function ipyart_ontwerp_maand( $ymd ) {
	static $m = array( '', 'januari', 'februari', 'maart', 'april', 'mei', 'juni', 'juli', 'augustus', 'september', 'oktober', 'november', 'december' );
	$t = strtotime( $ymd );
	return $t ? array( (int) gmdate( 'j', $t ), $m[ (int) gmdate( 'n', $t ) ], (int) gmdate( 'Y', $t ), (int) gmdate( 'n', $t ) ) : null;
}

/**
 * Datum als ['groot' => '11–15', 'klein' => 'november 2026'].
 */
function ipyart_ontwerp_datum( $id ) {
	$tekst = get_post_meta( $id, 'ipyart_datumtekst', true );
	$start = get_post_meta( $id, 'ipyart_start', true );
	$eind  = get_post_meta( $id, 'ipyart_eind', true );

	if ( $tekst ) {
		return array( 'groot' => $tekst, 'klein' => '' );
	}

	$a = ipyart_ontwerp_maand( $start );
	if ( ! $a ) {
		return array( 'groot' => '', 'klein' => '' );
	}
	$b = ( $eind && $eind !== $start ) ? ipyart_ontwerp_maand( $eind ) : null;

	if ( ! $b ) {
		return array( 'groot' => (string) $a[0], 'klein' => $a[1] . ' ' . $a[2] );
	}
	if ( $a[3] === $b[3] && $a[2] === $b[2] ) {
		return array( 'groot' => $a[0] . '–' . $b[0], 'klein' => $a[1] . ' ' . $a[2] );
	}
	return array( 'groot' => $a[0] . ' ' . substr( $a[1], 0, 3 ) . ' – ' . $b[0] . ' ' . substr( $b[1], 0, 3 ), 'klein' => (string) $b[2] );
}

function ipyart_ontwerp_agenda_items( $toon ) {
	$vandaag = current_time( 'Y-m-d' );
	$posts   = get_posts(
		array(
			'post_type'      => 'agenda_item',
			'post_status'    => 'publish',
			'posts_per_page' => 100,
			'no_found_rows'  => true,
		)
	);

	$items = array();
	foreach ( $posts as $p ) {
		$start = get_post_meta( $p->ID, 'ipyart_start', true );
		$eind  = get_post_meta( $p->ID, 'ipyart_eind', true ) ?: $start;
		$komend = ( $eind ?: '0000-00-00' ) >= $vandaag;
		if ( ( 'komend' === $toon ) === $komend ) {
			$items[] = array( 'post' => $p, 'start' => $start ?: '0000-00-00' );
		}
	}
	usort( $items, function ( $x, $y ) use ( $toon ) {
		return 'komend' === $toon ? strcmp( $x['start'], $y['start'] ) : strcmp( $y['start'], $x['start'] );
	} );

	return wp_list_pluck( $items, 'post' );
}

function ipyart_ontwerp_agenda_kaart( $p, $knop = false ) {
	$d    = ipyart_ontwerp_datum( $p->ID );
	$soort = get_post_meta( $p->ID, 'ipyart_soort', true );
	$loc   = get_post_meta( $p->ID, 'ipyart_locatie', true );
	$tijd  = get_post_meta( $p->ID, 'ipyart_tijd', true );
	$tekst = get_post_meta( $p->ID, 'ipyart_tekst', true );
	$extra = get_post_meta( $p->ID, 'ipyart_extra', true );

	$o  = '<article class="ipyart-agenda-kaart is-style-kaart"><div class="ipyart-agenda-kaart__datum">';
	$o .= '<p class="ipyart-datum">' . esc_html( $d['groot'] ) . '</p>';
	if ( $d['klein'] ) {
		$o .= '<p class="is-style-label">' . esc_html( $d['klein'] ) . '</p>';
	}
	$logo = ipyart_ontwerp_foto_html( $p->ID, 'medium', get_the_title( $p ) );
	if ( $logo ) {
		$o .= '<figure class="ipyart-agenda-kaart__logo">' . $logo . '</figure>';
	}
	$o .= '</div><div class="ipyart-agenda-kaart__inhoud">';
	if ( $soort ) {
		$o .= '<p class="is-style-label">' . esc_html( $soort ) . '</p>';
	}
	$o .= '<h3>' . esc_html( get_the_title( $p ) . ( $loc ? ', ' . $loc : '' ) ) . '</h3>';
	if ( $tijd ) {
		$o .= '<p class="ipyart-agenda-tijd">' . esc_html( $tijd ) . '</p>';
	}
	if ( $tekst ) {
		$o .= '<p>' . esc_html( $tekst ) . '</p>';
	}
	if ( $extra ) {
		$o .= '<p><strong>' . esc_html( $extra ) . '</strong></p>';
	}
	$o .= ipyart_ontwerp_video_html( get_post_meta( $p->ID, 'ipyart_video', true ), get_the_title( $p ) );
	if ( $knop ) {
		$o .= '<div class="wp-block-buttons"><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="' . esc_url( home_url( '/agenda/' ) ) . '">Bekijk de agenda</a></div></div>';
	}
	return $o . '</div></article>';
}

function ipyart_ontwerp_agenda_eerder_rij( $p ) {
	$d     = ipyart_ontwerp_datum( $p->ID );
	$soort = get_post_meta( $p->ID, 'ipyart_soort', true );
	$tekst = get_post_meta( $p->ID, 'ipyart_tekst', true );
	$beeld = ipyart_ontwerp_foto_html( $p->ID, 'medium', get_the_title( $p ) );

	$o  = '<article class="ipyart-agenda-eerder">';
	$o .= '<div class="ipyart-agenda-eerder__datum"><p class="ipyart-datum">' . esc_html( $d['groot'] ) . '</p>' . ( $d['klein'] ? '<p class="is-style-label">' . esc_html( $d['klein'] ) . '</p>' : '' ) . '</div>';
	$o .= '<div class="ipyart-agenda-eerder__inhoud">';
	if ( $soort ) {
		$o .= '<p class="is-style-label">' . esc_html( $soort ) . '</p>';
	}
	$o .= '<h3>' . esc_html( get_the_title( $p ) ) . '</h3>';
	if ( $tekst ) {
		$o .= '<p>' . esc_html( $tekst ) . '</p>';
	}
	$o .= '</div>';
	if ( $beeld ) {
		$o .= '<figure class="ipyart-agenda-eerder__beeld">' . $beeld . '</figure>';
	}
	$video = ipyart_ontwerp_video_html( get_post_meta( $p->ID, 'ipyart_video', true ), get_the_title( $p ) );
	if ( $video ) {
		$o .= '<div class="ipyart-agenda-eerder__video">' . $video . '</div>';
	}
	return $o . '</article>';
}

add_shortcode( 'ipyart_agenda', 'ipyart_ontwerp_agenda_shortcode' );

function ipyart_ontwerp_agenda_shortcode( $atts ) {
	$atts  = shortcode_atts( array( 'toon' => 'komend' ), $atts, 'ipyart_agenda' );
	$toon  = 'eerder' === $atts['toon'] ? 'eerder' : 'komend';
	$posts = ipyart_ontwerp_agenda_items( $toon );

	if ( ! $posts ) {
		return 'komend' === $toon
			? '<p>Op dit moment staat er niets gepland. Meld je aan voor de nieuwsbrief, dan hoor je het als eerste.</p>'
			: '';
	}

	$out = '<div class="ipyart-agenda">';
	foreach ( $posts as $p ) {
		$out .= 'komend' === $toon ? ipyart_ontwerp_agenda_kaart( $p ) : ipyart_ontwerp_agenda_eerder_rij( $p );
	}
	return $out . '</div>';
}

add_shortcode( 'ipyart_agenda_volgende', 'ipyart_ontwerp_agenda_volgende_shortcode' );

function ipyart_ontwerp_agenda_volgende_shortcode() {
	$posts = ipyart_ontwerp_agenda_items( 'komend' );
	if ( ! $posts ) {
		return '<p class="has-text-align-center">Op dit moment staat er niets gepland. Meld je aan voor de nieuwsbrief, dan hoor je het als eerste.</p>';
	}
	return ipyart_ontwerp_agenda_kaart( $posts[0], true );
}
