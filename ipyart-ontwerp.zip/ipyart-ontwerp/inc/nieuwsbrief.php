<?php
/**
 * Nieuwsbrief en pop-up.
 *
 * Formulier, in volgorde van voorkeur:
 * 1. MailerLite (account-ID + formulier-ID ingevuld bij Instellingen → IPY ART)
 * 2. Het bestaande WPForms-nieuwsbriefformulier (standaard ID 356), zolang MailerLite nog niet gekoppeld is
 *
 * - [ipyart_nieuwsbrief] toont het formulier (footer, nieuwsbriefblokken).
 * - De pop-up is een eigen dialoog in de huisstijl met hetzelfde formulier. Hij laadt alleen als het ontwerp actief is.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', 'ipyart_ontwerp_register_nieuwsbrief_settings' );
add_action( 'admin_init', 'ipyart_ontwerp_register_nieuwsbrief_settings' );

function ipyart_ontwerp_register_nieuwsbrief_settings() {
	register_setting(
		'ipyart_ontwerp',
		'ipyart_nieuwsbrief_wpforms',
		array(
			'type'              => 'string',
			'description'       => 'ID van het WPForms-nieuwsbriefformulier (zolang MailerLite niet gekoppeld is).',
			'default'           => '356',
			'sanitize_callback' => function ( $value ) {
				return preg_replace( '/[^0-9]/', '', (string) $value );
			},
			'show_in_rest'      => true,
		)
	);

	register_setting(
		'ipyart_ontwerp',
		'ipyart_popup',
		array(
			'type'              => 'string',
			'description'       => 'Nieuwsbrief-pop-up: aan of uit.',
			'default'           => 'aan',
			'sanitize_callback' => function ( $value ) {
				return 'uit' === $value ? 'uit' : 'aan';
			},
			'show_in_rest'      => array(
				'schema' => array(
					'type' => 'string',
					'enum' => array( 'aan', 'uit' ),
				),
			),
		)
	);
}

function ipyart_ontwerp_mailerlite_gekoppeld() {
	return '' !== get_option( 'ipyart_mailerlite_account', '' ) && '' !== get_option( 'ipyart_mailerlite_form', '' );
}

/**
 * Het formulier als HTML, of '' als er (nog) geen formulier is.
 */
function ipyart_ontwerp_nieuwsbrief_formulier() {
	if ( ipyart_ontwerp_mailerlite_gekoppeld() ) {
		return sprintf( '<div class="ipyart-nieuwsbrief ml-embedded" data-form="%s"></div>', esc_attr( get_option( 'ipyart_mailerlite_form' ) ) );
	}

	$wpforms = get_option( 'ipyart_nieuwsbrief_wpforms', '356' );
	if ( '' !== $wpforms && shortcode_exists( 'wpforms' ) && 'wpforms' === get_post_type( (int) $wpforms ) ) {
		return '<div class="ipyart-nieuwsbrief ipyart-nieuwsbrief--wpforms">' . do_shortcode( sprintf( '[wpforms id="%d" title="false" description="false"]', (int) $wpforms ) ) . '</div>';
	}

	return '';
}

add_shortcode( 'ipyart_nieuwsbrief', 'ipyart_ontwerp_nieuwsbrief_shortcode' );

function ipyart_ontwerp_nieuwsbrief_shortcode() {
	$form = ipyart_ontwerp_nieuwsbrief_formulier();

	if ( '' !== $form ) {
		return $form;
	}

	// Geen formulier: alleen redacteuren zien een melding, bezoekers niets.
	if ( current_user_can( 'edit_pages' ) ) {
		return '<p class="ipyart-nieuwsbrief-leeg">[Nieuwsbriefformulier: koppel MailerLite of kies een WPForms-formulier bij Instellingen → IPY ART]</p>';
	}

	return '';
}

/**
 * MailerLite universal-script (alleen als MailerLite gekoppeld is en het ontwerp actief is).
 */
add_action( 'wp_head', 'ipyart_ontwerp_mailerlite_script', 20 );

function ipyart_ontwerp_mailerlite_script() {
	$account = get_option( 'ipyart_mailerlite_account', '' );

	if ( '' === $account || ! ipyart_ontwerp_actief() ) {
		return;
	}
	?>
<!-- MailerLite Universal -->
<script>
(function(w,d,e,u,f,l,n){w[f]=w[f]||function(){(w[f].q=w[f].q||[]).push(arguments);},l=d.createElement(e),l.async=1,l.src=u,n=d.getElementsByTagName(e)[0],n.parentNode.insertBefore(l,n);})(window,document,'script','https://assets.mailerlite.com/js/universal.js','ml');
ml('account', '<?php echo esc_js( $account ); ?>');
</script>
<!-- End MailerLite Universal -->
	<?php
}

/**
 * Teksten van de pop-up (aan te passen met de filter ipyart_popup_tekst).
 */
function ipyart_ontwerp_popup_tekst() {
	return apply_filters(
		'ipyart_popup_tekst',
		array(
			'label'      => 'Nieuwsbrief',
			'titel'      => 'Hoor het als eerste',
			'tekst'      => 'Mijn eerste single Duck Dive komt eraan, en van 11 tot en met 15 november exposeer ik bij Appie Gallery in Amsterdam. Meld je aan en ik laat het je als eerste weten.',
			'klein'      => 'Ongeveer één keer per maand. Afmelden kan altijd.',
			'afbeelding' => 'https://ipyart.com/wp-content/uploads/2025/01/OSS_5614-1024x1022.jpg',
			'alt'        => 'Schilderij Love you deeply uit de Lovers-serie',
			'uitsluiten' => array( 'contact', 'privacy' ),
		)
	);
}

function ipyart_ontwerp_popup_tonen() {
	if ( ! ipyart_ontwerp_actief() || 'uit' === get_option( 'ipyart_popup', 'aan' ) || is_admin() ) {
		return false;
	}

	$tekst = ipyart_ontwerp_popup_tekst();
	if ( is_page( $tekst['uitsluiten'] ) ) {
		return false;
	}

	return '' !== ipyart_ontwerp_nieuwsbrief_formulier();
}

add_action( 'wp_enqueue_scripts', 'ipyart_ontwerp_popup_assets', 30 );

function ipyart_ontwerp_popup_assets() {
	if ( ! ipyart_ontwerp_popup_tonen() ) {
		return;
	}

	wp_enqueue_script(
		'ipyart-popup',
		IPYART_ONTWERP_URL . 'assets/popup.js',
		array(),
		IPYART_ONTWERP_VERSION . '.' . (int) filemtime( IPYART_ONTWERP_DIR . 'assets/popup.js' ),
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
}

add_action( 'wp_footer', 'ipyart_ontwerp_popup_markup', 5 );

function ipyart_ontwerp_popup_markup() {
	if ( ! ipyart_ontwerp_popup_tonen() ) {
		return;
	}

	$t = ipyart_ontwerp_popup_tekst();
	?>
<div class="ipy-popup" id="ipy-popup" hidden>
	<div class="ipy-popup__achtergrond" data-ipy-sluit></div>
	<div class="ipy-popup__venster" role="dialog" aria-modal="true" aria-labelledby="ipy-popup-titel" aria-describedby="ipy-popup-tekst" tabindex="-1">
		<button type="button" class="ipy-popup__sluit" data-ipy-sluit aria-label="Sluiten">
			<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>
		</button>
		<figure class="ipy-popup__beeld"><img src="<?php echo esc_url( $t['afbeelding'] ); ?>" alt="<?php echo esc_attr( $t['alt'] ); ?>" loading="lazy" decoding="async"></figure>
		<div class="ipy-popup__inhoud">
			<p class="is-style-label"><?php echo esc_html( $t['label'] ); ?></p>
			<h2 id="ipy-popup-titel" class="ipy-popup__titel"><?php echo esc_html( $t['titel'] ); ?></h2>
			<p id="ipy-popup-tekst"><?php echo esc_html( $t['tekst'] ); ?></p>
			<?php echo ipyart_ontwerp_nieuwsbrief_formulier(); // phpcs:ignore WordPress.Security.EscapeOutput -- formulier-HTML van MailerLite/WPForms. ?>
			<p class="ipy-popup__klein"><?php echo esc_html( $t['klein'] ); ?> <a href="<?php echo esc_url( home_url( '/privacy/' ) ); ?>">Privacy</a></p>
		</div>
	</div>
</div>
	<?php
}
