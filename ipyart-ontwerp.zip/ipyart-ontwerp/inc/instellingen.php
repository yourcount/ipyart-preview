<?php
/**
 * Instellingen (Instellingen → IPY ART). Ook via REST te beheren: /wp/v2/settings.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', 'ipyart_ontwerp_register_settings' );
add_action( 'admin_init', 'ipyart_ontwerp_register_settings' );

function ipyart_ontwerp_register_settings() {
	register_setting(
		'ipyart_ontwerp',
		'ipyart_ontwerp_modus',
		array(
			'type'              => 'string',
			'description'       => 'uit, preview of live.',
			'default'           => 'preview',
			'sanitize_callback' => function ( $value ) {
				return in_array( $value, array( 'uit', 'preview', 'live' ), true ) ? $value : 'preview';
			},
			'show_in_rest'      => array(
				'schema' => array(
					'type' => 'string',
					'enum' => array( 'uit', 'preview', 'live' ),
				),
			),
		)
	);

	register_setting(
		'ipyart_ontwerp',
		'ipyart_mailerlite_account',
		array(
			'type'              => 'string',
			'description'       => 'MailerLite account-ID (uit de "universal" JavaScript-snippet).',
			'default'           => '',
			'sanitize_callback' => function ( $value ) {
				return preg_replace( '/[^0-9]/', '', (string) $value );
			},
			'show_in_rest'      => true,
		)
	);

	register_setting(
		'ipyart_ontwerp',
		'ipyart_mailerlite_form',
		array(
			'type'              => 'string',
			'description'       => 'MailerLite ID van het ingesloten aanmeldformulier (data-form).',
			'default'           => '',
			'sanitize_callback' => function ( $value ) {
				return preg_replace( '/[^A-Za-z0-9]/', '', (string) $value );
			},
			'show_in_rest'      => true,
		)
	);
}

add_action( 'admin_menu', 'ipyart_ontwerp_admin_menu' );

function ipyart_ontwerp_admin_menu() {
	add_options_page( 'IPY ART', 'IPY ART', 'manage_options', 'ipyart-ontwerp', 'ipyart_ontwerp_settings_page' );
}

function ipyart_ontwerp_settings_page() {
	$modus = get_option( 'ipyart_ontwerp_modus', 'preview' );
	?>
	<div class="wrap">
		<h1>IPY ART</h1>
		<form method="post" action="options.php">
			<?php settings_fields( 'ipyart_ontwerp' ); ?>
			<h2>Nieuw ontwerp</h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row">Modus</th>
					<td>
						<fieldset>
							<label><input type="radio" name="ipyart_ontwerp_modus" value="uit" <?php checked( $modus, 'uit' ); ?>> <strong>Uit</strong>: niemand ziet het nieuwe ontwerp.</label><br>
							<label><input type="radio" name="ipyart_ontwerp_modus" value="preview" <?php checked( $modus, 'preview' ); ?>> <strong>Preview</strong>: alleen ingelogde beheerders die de preview aanzetten (via de knop in de adminbalk).</label><br>
							<label><input type="radio" name="ipyart_ontwerp_modus" value="live" <?php checked( $modus, 'live' ); ?>> <strong>Live</strong>: iedereen ziet het nieuwe ontwerp.</label>
						</fieldset>
					</td>
				</tr>
			</table>
			<h2>Nieuwsbrief (MailerLite)</h2>
			<p>Zonder account-ID laadt er niets van MailerLite; dan gebruiken footer en pop-up het WPForms-formulier hieronder.</p>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="ipyart_mailerlite_account">Account-ID</label></th>
					<td><input name="ipyart_mailerlite_account" id="ipyart_mailerlite_account" type="text" class="regular-text" value="<?php echo esc_attr( get_option( 'ipyart_mailerlite_account', '' ) ); ?>"></td>
				</tr>
				<tr>
					<th scope="row"><label for="ipyart_mailerlite_form">Formulier-ID</label></th>
					<td><input name="ipyart_mailerlite_form" id="ipyart_mailerlite_form" type="text" class="regular-text" value="<?php echo esc_attr( get_option( 'ipyart_mailerlite_form', '' ) ); ?>">
					<p class="description">Het ingesloten formulier verschijnt overal waar het blok of de shortcode <code>[ipyart_nieuwsbrief]</code> staat.</p></td>
				</tr>
				<tr>
					<th scope="row"><label for="ipyart_nieuwsbrief_wpforms">WPForms-formulier (tijdelijk)</label></th>
					<td><input name="ipyart_nieuwsbrief_wpforms" id="ipyart_nieuwsbrief_wpforms" type="text" class="small-text" value="<?php echo esc_attr( get_option( 'ipyart_nieuwsbrief_wpforms', '356' ) ); ?>">
					<p class="description">Wordt gebruikt zolang MailerLite niet gekoppeld is. Nu: het bestaande nieuwsbriefformulier.</p></td>
				</tr>
				<tr>
					<th scope="row">Pop-up</th>
					<td><label><input type="radio" name="ipyart_popup" value="aan" <?php checked( get_option( 'ipyart_popup', 'aan' ), 'aan' ); ?>> Aan</label>
					&nbsp; <label><input type="radio" name="ipyart_popup" value="uit" <?php checked( get_option( 'ipyart_popup', 'aan' ), 'uit' ); ?>> Uit</label>
					<p class="description">Na 30 seconden, bij 50% scrollen of als iemand de pagina wil verlaten. Na sluiten 30 dagen niet opnieuw, na aanmelden nooit meer. Testen: voeg <code>?ipy-popup=1</code> toe aan een URL.</p></td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}
