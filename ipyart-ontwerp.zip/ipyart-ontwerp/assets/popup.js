/**
 * IPY ART — nieuwsbrief-pop-up.
 *
 * Verschijnt na 30 seconden, bij 50% scrollen of bij exit-intent (desktop), één keer per bezoek.
 * Na sluiten 30 dagen niet opnieuw; na aanmelden nooit meer. ?ipy-popup=1 toont hem direct (testen).
 * Toegankelijk: dialoog met focus erin, Esc sluit, focus terug naar waar je was.
 */
( function () {
	var popup = document.getElementById( 'ipy-popup' );
	if ( ! popup ) {
		return;
	}

	var venster = popup.querySelector( '.ipy-popup__venster' );
	var DAG = 24 * 60 * 60 * 1000;
	var KEY_DICHT = 'ipy_popup_dicht';
	var KEY_LID = 'ipy_nieuwsbrief_lid';
	var getoond = false;
	var vorigeFocus = null;
	var forceer = /[?&]ipy-popup=1/.test( window.location.search );

	function lees( key ) {
		try {
			return window.localStorage.getItem( key );
		} catch ( e ) {
			return null;
		}
	}

	function schrijf( key, value ) {
		try {
			window.localStorage.setItem( key, value );
		} catch ( e ) {}
	}

	function magTonen() {
		if ( forceer ) {
			return true;
		}
		if ( lees( KEY_LID ) ) {
			return false;
		}
		var dicht = parseInt( lees( KEY_DICHT ) || '0', 10 );
		return ! dicht || Date.now() - dicht > 30 * DAG;
	}

	function focusbaar() {
		return Array.prototype.filter.call(
			venster.querySelectorAll( 'a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select, textarea, [tabindex]:not([tabindex="-1"])' ),
			function ( el ) {
				return el.offsetParent !== null;
			}
		);
	}

	function toon() {
		if ( getoond || ! magTonen() ) {
			return;
		}
		getoond = true;
		vorigeFocus = document.activeElement;
		popup.hidden = false;
		document.documentElement.classList.add( 'ipy-popup-open' );
		requestAnimationFrame( function () {
			popup.classList.add( 'is-open' );
			var eerste = venster.querySelector( 'input[type="email"], input:not([type="hidden"])' );
			( eerste || venster ).focus( { preventScroll: true } );
		} );
		document.addEventListener( 'keydown', toetsen );
	}

	function sluit() {
		popup.classList.remove( 'is-open' );
		document.documentElement.classList.remove( 'ipy-popup-open' );
		document.removeEventListener( 'keydown', toetsen );
		if ( ! lees( KEY_LID ) ) {
			schrijf( KEY_DICHT, String( Date.now() ) );
		}
		window.setTimeout( function () {
			popup.hidden = true;
		}, 350 );
		if ( vorigeFocus && vorigeFocus.focus ) {
			vorigeFocus.focus( { preventScroll: true } );
		}
	}

	function toetsen( e ) {
		if ( e.key === 'Escape' ) {
			e.preventDefault();
			sluit();
			return;
		}
		if ( e.key !== 'Tab' ) {
			return;
		}
		var els = focusbaar();
		if ( ! els.length ) {
			return;
		}
		var eerste = els[ 0 ];
		var laatste = els[ els.length - 1 ];
		if ( e.shiftKey && document.activeElement === eerste ) {
			e.preventDefault();
			laatste.focus();
		} else if ( ! e.shiftKey && document.activeElement === laatste ) {
			e.preventDefault();
			eerste.focus();
		}
	}

	popup.addEventListener( 'click', function ( e ) {
		if ( e.target.closest( '[data-ipy-sluit]' ) ) {
			sluit();
		}
	} );

	// Aangemeld (via de pop-up of het formulier in de footer): nooit meer tonen.
	document.addEventListener( 'submit', function ( e ) {
		if ( e.target.closest( '.ipyart-nieuwsbrief' ) ) {
			schrijf( KEY_LID, '1' );
		}
	}, true );

	if ( ! magTonen() ) {
		return;
	}

	if ( forceer ) {
		window.setTimeout( toon, 300 );
		return;
	}

	// Na 30 seconden.
	window.setTimeout( toon, 30000 );

	// Bij 50% scrollen.
	window.addEventListener( 'scroll', function opScroll() {
		var max = document.documentElement.scrollHeight - window.innerHeight;
		if ( max > 0 && window.scrollY / max >= 0.5 ) {
			window.removeEventListener( 'scroll', opScroll );
			toon();
		}
	}, { passive: true } );

	// Exit-intent op desktop: muis verlaat het venster aan de bovenkant.
	if ( window.matchMedia( '(hover: hover) and (pointer: fine)' ).matches ) {
		document.addEventListener( 'mouseout', function opExit( e ) {
			if ( ! e.relatedTarget && e.clientY <= 0 ) {
				document.removeEventListener( 'mouseout', opExit );
				toon();
			}
		} );
	}
} )();
