/**
 * Fotokiezer voor de referentiefoto bij Werk.
 */
( function ( $ ) {
	'use strict';

	$( document ).on( 'click', '.ipyart-kies-foto', function ( e ) {
		e.preventDefault();
		var $veld = $( this ).closest( '.ipyart-foto-veld' );
		var frame = wp.media( { title: 'Kies de referentiefoto', button: { text: 'Gebruik deze foto' }, multiple: false, library: { type: 'image' } } );

		frame.on( 'select', function () {
			var a = frame.state().get( 'selection' ).first().toJSON();
			var url = a.sizes && a.sizes.thumbnail ? a.sizes.thumbnail.url : a.url;
			$veld.find( 'input[type="hidden"]' ).val( a.id );
			$veld.find( '.ipyart-foto-voorbeeld' ).html( $( '<img>' ).attr( 'src', url ) );
			$veld.find( '.ipyart-verwijder-foto' ).show();
		} );

		frame.open();
	} );

	$( document ).on( 'click', '.ipyart-verwijder-foto', function ( e ) {
		e.preventDefault();
		var $veld = $( this ).closest( '.ipyart-foto-veld' );
		$veld.find( 'input[type="hidden"]' ).val( '' );
		$veld.find( '.ipyart-foto-voorbeeld' ).empty();
		$( this ).hide();
	} );
}( jQuery ) );
