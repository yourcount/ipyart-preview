/**
 * IPY ART — subtiele scroll-animaties.
 *
 * - Zonder JavaScript, of bij "minder beweging", is alle content direct zichtbaar.
 * - De klasse die content tijdelijk verbergt (ipy-anim) wordt pas als laatste stap gezet,
 *   zodat een fout in dit script nooit content onzichtbaar kan laten.
 */
( function () {
	if ( window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches || ! ( 'IntersectionObserver' in window ) ) {
		return;
	}

	var content = document.querySelector( '.wp-block-post-content' ) || document.querySelector( 'main' );
	if ( ! content ) {
		return;
	}

	var selectors = [
		'.wp-block-post-content > .alignfull:not(:first-child) :is(h2, p.is-style-label, .wp-block-quote, .wp-block-column, .ipyart-paar)',
		'.wp-block-post-content > .alignfull:not(:first-child) .wp-block-gallery > .wp-block-image',
		'.ipyart-gedichten .wp-block-post',
		'hr.wp-block-separator.is-style-goud',
	].join( ',' );

	var items = Array.prototype.slice.call( document.querySelectorAll( selectors ) );
	if ( ! items.length ) {
		return;
	}

	function toon( el ) {
		el.classList.add( 'is-zichtbaar' );
	}

	var observer = new IntersectionObserver(
		function ( entries ) {
			entries.forEach( function ( entry ) {
				if ( entry.isIntersecting ) {
					toon( entry.target );
					observer.unobserve( entry.target );
				}
			} );
		},
		{ rootMargin: '0px 0px -6% 0px', threshold: 0 }
	);

	items.forEach( function ( el ) {
		// Wat bij het laden al in beeld staat, meteen tonen (geen flits).
		if ( el.getBoundingClientRect().top < window.innerHeight * 0.94 ) {
			toon( el );
			return;
		}

		el.classList.add( 'ipy-onthul' );

		// Broertjes in een rij (kolommen, galerij) licht na elkaar.
		var siblings = Array.prototype.filter.call( el.parentNode.children, function ( c ) {
			return c.matches( selectors );
		} );
		var index = siblings.indexOf( el );
		if ( index > 0 ) {
			el.style.transitionDelay = Math.min( index, 5 ) * 90 + 'ms';
		}

		observer.observe( el );
	} );

	// Vangnet: wat (bijna) in beeld is of onderaan de pagina staat, altijd tonen.
	// Niet afhankelijk van requestAnimationFrame (dat browsers op de achtergrond afknijpen).
	function controleer() {
		var onderaan = window.scrollY + window.innerHeight >= document.documentElement.scrollHeight - 4;
		document.querySelectorAll( '.ipy-onthul:not(.is-zichtbaar)' ).forEach( function ( el ) {
			if ( onderaan || el.getBoundingClientRect().top < window.innerHeight * 0.96 ) {
				toon( el );
				observer.unobserve( el );
			}
		} );
	}

	var laatste = 0;
	var eind = null;
	window.addEventListener( 'scroll', function () {
		var nu = Date.now();
		if ( nu - laatste > 100 ) {
			laatste = nu;
			controleer();
		}
		window.clearTimeout( eind );
		eind = window.setTimeout( controleer, 150 );
	}, { passive: true } );
	window.addEventListener( 'resize', controleer );
	window.addEventListener( 'load', controleer );

	// Pas nu alles klaarstaat de animaties aanzetten.
	document.documentElement.classList.add( 'ipy-anim' );
} )();
