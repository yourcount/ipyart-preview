/**
 * IPY ART — subtiele animaties.
 * Content is altijd zichtbaar zonder JavaScript; deze code voegt alleen klassen toe.
 * Bij "minder beweging" (prefers-reduced-motion) gebeurt er niets.
 */
( function () {
	if ( window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches || ! ( 'IntersectionObserver' in window ) ) {
		return;
	}

	var root = document.documentElement;
	root.classList.add( 'ipy-anim' );

	var content = document.querySelector( '.wp-block-post-content, main' );
	if ( ! content ) {
		return;
	}

	// Eerste sectie: direct bij laden, met het beeld als "maan die opkomt".
	var first = document.querySelector( '.wp-block-post-content > .alignfull:first-child' );
	if ( first ) {
		first.classList.add( 'ipy-hero' );
		requestAnimationFrame( function () {
			requestAnimationFrame( function () {
				first.classList.add( 'is-zichtbaar' );
			} );
		} );
	}

	// Alles daarna: zacht omhoog faden zodra het in beeld komt.
	var selectors = [
		'.wp-block-post-content > .alignfull:not(:first-child) :is(h2, .is-style-label, .wp-block-quote)',
		'.wp-block-post-content > .alignfull:not(:first-child) .wp-block-column',
		'.wp-block-post-content > .alignfull:not(:first-child) .wp-block-gallery > .wp-block-image',
		'.wp-block-post-content > .alignfull:not(:first-child) .ipyart-paar',
		'.ipyart-gedichten .wp-block-post',
		'.ipyart-gedicht .wp-block-post-content',
		'hr.is-style-goud',
	];

	var items = content.parentNode.querySelectorAll( selectors.join( ',' ) );

	var observer = new IntersectionObserver(
		function ( entries ) {
			entries.forEach( function ( entry ) {
				if ( entry.isIntersecting ) {
					entry.target.classList.add( 'is-zichtbaar' );
					observer.unobserve( entry.target );
				}
			} );
		},
		{ rootMargin: '0px 0px -6% 0px', threshold: 0 }
	);

	items.forEach( function ( el ) {
		if ( first && first.contains( el ) ) {
			return;
		}
		el.classList.add( 'ipy-onthul' );

		// Broertjes in een rij (kolommen, galerij) licht na elkaar.
		var siblings = el.parentNode ? Array.prototype.filter.call( el.parentNode.children, function ( c ) {
			return c.matches && c.matches( selectors.join( ',' ) );
		} ) : [];
		var index = siblings.indexOf( el );
		if ( index > 0 ) {
			el.style.transitionDelay = Math.min( index, 5 ) * 90 + 'ms';
		}

		observer.observe( el );
	} );

	// Vangnet: wat al (bijna) in beeld is of onderaan de pagina staat, altijd tonen.
	var wacht = false;
	function controleer() {
		wacht = false;
		var onderaan = window.scrollY + window.innerHeight >= document.documentElement.scrollHeight - 4;
		document.querySelectorAll( '.ipy-onthul:not(.is-zichtbaar)' ).forEach( function ( el ) {
			if ( onderaan || el.getBoundingClientRect().top < window.innerHeight * 0.96 ) {
				el.classList.add( 'is-zichtbaar' );
				observer.unobserve( el );
			}
		} );
	}
	window.addEventListener( 'scroll', function () {
		if ( ! wacht ) {
			wacht = true;
			window.requestAnimationFrame( controleer );
		}
	}, { passive: true } );
	window.addEventListener( 'load', controleer );
} )();
